---
# Metadata used for sync
id: "4ad7f170-6b5d-11ed-954f-319196f48bd7"
title: ""
source: ""
created_date: "2022-11-24"
modified_date: "2022-11-24"
deleted: true
---
 Beyond a certain skill cap success  Purely about decision making.

You're doubting yourself meawhile
people are wondering how you do
it all so effortlessly. Give yourself
more credit

Success is the result of
your consistency
invisibly compounding
for or against you, over
long periods of time.

90% perfect and shared with the world
always changes more lives than 100%
perfect and stuck in your head.