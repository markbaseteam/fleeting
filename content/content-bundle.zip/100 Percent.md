---
# Metadata used for sync
id: "bdc11920-520b-11ed-b677-5f20ca30b049"
title: "100 Percent"
source: ""
created_date: "2022-10-22"
modified_date: "2022-10-22"
deleted: true
---
I don't think I'm giving
my 100%

First clarify yourself...
1) Do you think?
2) Do you believe?
|3) Do you know?|
First 2 are absurd way of speech. Either you
know, or you don't. That's it. And now if you
know that you aren't giving 100% then |
retrace the livelihood and find the thing
| that's blocking you to be 100%.
Actions should be spontan eous once you
are clear over your things. Why to delay?

 