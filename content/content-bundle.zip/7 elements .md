---
id: f2f9f630-7302-11ed-868a-9724eabee8f6
title: 7 elements 
tags: 
source: 
created_date: 2022-12-03
modified_date: 2022-12-03
deleted: true
---
Character reacting to some situation 
1. Chance 
meri bestfriend ki shaadi by krishnasingh
Internal
  Pysochologlical , socially emotional and pylosocally cannot physically show
External change  location, height change, weight change from school to college
Social change        reform independence,girl child, related to awareness
Can be from boy to man like waku up sid
2.Self - protagonist
Character desire, experiences facing that desire like ms shone movie
The desire can be changed 
3. Other - might be antagonist or can help protagonist
4. Conflict - which grabs attention everywhere   types like internal means social pressure  external like murders, deaths, quarrel 
Can have multiple conflicts
5. Event - that is happening not routine
The event that starts the whole story
6. Structure of movie : 3-acts structure
25 % intro exposition
50 % buildpt up - turning points, conflicts, complications 
25 % climax or resolution 
⁵ - acts structure
Act 2 50% is divided into 3 acts conflict, resolve, conflict, resolve like this
7. Emotion -most important 
Eg: the man killed the lion
The man was afraid of lion but still he killed lion
The man has daughter which is born after 12 years 

You know yourself best 
Never lose touch with your mother tounge
Collaborate with other forms of arts

Archtypal reactions

Anish chaganti youtube video


7 element for story writing