---
# Metadata used for sync
id: "ffc588d0-5461-11ed-b2af-b975c3c56916"
title: "A duff version"
source: ""
created_date: "2022-10-25"
modified_date: "2022-10-25"
deleted: true
---
A different version of you exists in
the minds of everyone who knows
you.
I read a book that blew my mind. The main
character goes crazy when he realizes no one
really knows him.
The gist is that the person you think of as
"yourself" exists only for you, and even you don't
really know who that is. Every person you meet,
have a relationship with or make eye contact
on the street with, creates a version of "you"
in their heads. You're not the same person to
your mom, your dad, your siblings, than you
are to your coworkers, your neighbours or your
friends. There area thousand different versions
of yourself out there, in people's minds. A "you"
exists in each version, and yet your "you",
"vourself" isn't reallv a "someone" at all. 