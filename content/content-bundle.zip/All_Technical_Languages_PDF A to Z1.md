---
# Metadata used for sync
id: "c3ea3b70-7302-11ed-868a-9724eabee8f6"
title: ""
# Extracts all tags in content into the metadata
tags: []
source: ""
created_date: "2022-12-03"
modified_date: "2022-12-03"
deleted: true
---
🔰All_Technical_Languages_PDF A to Z🔰

1- .NET FRAMEWORK-

https://books.goalkicker.com/DotNETFrameworkBook/

2- Algorithms-

https://books.goalkicker.com/AlgorithmsBook/

3- Android-

https://books.goalkicker.com/AndroidBook/

4- Angular 2

https://books.goalkicker.com/Angular2Book/

5- Angular JS 

https://books.goalkicker.com/AngularJSBook/

6- BASH 

https://books.goalkicker.com/BashBook/

7- C

https://books.goalkicker.com/CBook/

8- C++

https://books.goalkicker.com/CPlusPlusBook/

9- C#

https://books.goalkicker.com/CSharpBook/

10- CSS

https://books.goalkicker.com/CSSBook/

11- Entity Framework-

https://books.goalkicker.com/EntityFrameworkBook/

12- Excel VBA

https://books.goalkicker.com/ExcelVBABook/

13- GIT 

https://books.goalkicker.com/GitBook/

14- Haskell

https://books.goalkicker.com/HaskellBook/

15- Hibernate

https://books.goalkicker.com/HibernateBook/

16- HTML 5

https://books.goalkicker.com/HTML5Book/

17- HTML5 CANVAS

https://books.goalkicker.com/HTML5CanvasBook/

18- iOS

https://books.goalkicker.com/iOSBook/

19- JAVA 

https://books.goalkicker.com/JavaBook/

20- JAVA SCRIPT

https://books.goalkicker.com/JavaScriptBook/

21- jQuery

https://books.goalkicker.com/jQueryBook/

22- KOTLIN

https://books.goalkicker.com/KotlinBook/

23- LaTex

https://books.goalkicker.com/LaTeXBook/

24- Linux

https://books.goalkicker.com/LinuxBook/

25- MATLAB

https://books.goalkicker.com/MATLABBook/

26- Microsoft SQL Server

https://books.goalkicker.com/MicrosoftSQLServerBook/

27- MongoDB

https://books.goalkicker.com/MongoDBBook/

28- MySQL

https://books.goalkicker.com/MySQLBook/

29- NodeJS

https://books.goalkicker.com/NodeJSBook/

30- Objective-C

https://books.goalkicker.com/ObjectiveCBook/

31- Oracle DB 

https://books.goalkicker.com/OracleDatabaseBook/

32- Perl  

https://books.goalkicker.com/PerlBook/

33- PHP

https://books.goalkicker.com/PHPBook/

34- PostgreSQL

https://books.goalkicker.com/PostgreSQLBook/

35- PowerShell

https://books.goalkicker.com/PowerShellBook/

36- Python

https://books.goalkicker.com/PythonBook/

37- R

https://books.goalkicker.com/RBook/

38- React JS 

https://books.goalkicker.com/ReactJSBook/

39- React Native

https://books.goalkicker.com/ReactNativeBook/

40- Ruby 

https://books.goalkicker.com/RubyBook/

41- Ruby on Rails

https://books.goalkicker.com/RubyOnRailsBook/

42- Spring Framework

https://books.goalkicker.com/SpringFrameworkBook/

43- SQL

https://books.goalkicker.com/SQLBook/

44- Swift

https://books.goalkicker.com/SwiftBook/

45- Type Script

https://books.goalkicker.com/TypeScriptBook2/

46- VBA 

https://books.goalkicker.com/VBABook/

47- Visual Basic .Net 

https://books.goalkicker.com/VisualBasic_NETBook/

48- Xamarin Forms 

https://books.goalkicker.com/XamarinFormsBook/

🔰Download Amazon e-Book For Free🔰

Ⓜ️All The Amazon e-Books Can Be Downloaded Free of Cost.

◾️Link:- http://gen.lib.rus.ec/

🔰 HOW TO GET EVERY E-BOOK YOU MAY NEED FOR FREE 🔰

 
Some of these sites also offer the possibility to choose the format for your e-book (.PDF, .EPUB, .MOBI, .AZW and so on

b-ok.org - Formerly known as Bookzz. Mirrors Libgen library with better navigation.
libgen.is -- (libgen.pw) - Most popular ebook site and provides several mirrors to ebooks including torrents. Textbook focused. If you have any textbook or any other educational book to share, this is the place. For any book not available, make a request in the respective thread in the forums.
libgen.pw - Libgen mirror
the-eye.eu/public/Books - The Eye's extensive eBooks archive
forcoder.su - Focuses on programming textbooks
mobilism.org - Large ebook forum that contains a request subforum
archive.org/details/texts - The Internet Archive's immense archive of ebooks.
freebookspot.es
ebookee.org
s2.bitdownload.ir - Open directory of Ebooks ( TheCyberArmy )
s3.bitdownload.ir - Open directory of Ebooks

🔰 All paid Ebooks free 🔰

Hacking, programming etc

https://mega.nz/folder/a18mXQIJ#9Ra_qH1y-S4Ejt4bENpkZQ