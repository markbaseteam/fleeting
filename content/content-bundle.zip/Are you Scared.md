---
# Metadata used for sync
id: "b636d1f0-520a-11ed-98b2-058d056d1cbb"
title: "Are you Scared? "
source: ""
created_date: "2022-10-22"
modified_date: "2022-10-22"
deleted: true
---
Are you scared or have any fear?
Are you scared of losing everything. Well
lost everything when I had clinical
depression. Including my desire to even
live.
So how does it feel to be at rock bottom of
all rock bottoms?
It's not that bad. Ihad no choice but to
accept my circumstances. But when
you're actually there it's not bad.
Because they're nothing much you can
do. And only slowly can you take you life
back again.
I've seen the very bottom of life and it's
not bad. And I got there from the absolute
top.
And all I can tell you is there's really
nothing to fear. Even in the worse of the
worst circumstances life finds a way :) 