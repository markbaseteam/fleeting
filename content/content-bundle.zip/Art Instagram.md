---
# Metadata used for sync
id: "00846240-5431-11ed-b0ef-fd6e295fe152"
title: "Art Instagram"
source: ""
created_date: "2022-10-25"
modified_date: "2022-10-25"
deleted: true
---
Don't write DM FOR ORDERS :

Q:What to write in bio if am a beginner artist?
A: Provide something for free to your audience and mention
it in your bio. This will help you convert people visiting your
profile into followers because people love FREE CONTENT!
As an artist you can provide following things for free:
Free Classes
Free E-Book
Free Wallpapers
Free Templates
Free lcons
Free llustrations
*Free Brushes
(Collect email addresses along this and grow your email list
too for marketing.)


Without face illustrations :
You can make fashion illustrations,
food illustrations, environment art,
do lettering, make kawaii style
illustrations of non-living things, etc
And ALSO CHECK FIVERR


