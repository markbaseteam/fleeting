---
# Metadata used for sync
id: "a3daa760-5431-11ed-b0ef-fd6e295fe152"
title: "Art Questions and all"
source: ""
created_date: "2022-10-25"
modified_date: "2022-10-25"
deleted: true
---
I feel like the pieces that I create for enjoyment
outside of my commissions is where I improve and
work on my skills the most. It's during those pieces
that I'll push myself to work on a skill that I might be
lacking on (e.g drawings hands and backgrounds). Tt
really helps to do a lot of studies. Literally grab a pic
off Google that you like and try to replicate it,
practice is honestly the best way to improve your
skills and also focusing on small parts. Don't
overwhelm yourself with loads to draw in one sitting.
Just focus on a finger, a plant or whatever it is, slowly
you'll start to see improvements as you build on that


#starting new sketchbook
1, Draw From Life or Photos
2. Make 'Sketch Notes' and Brainstorms
3. Do Mindless Scribbles
4. Test your Ideas
5. Copy other Artists
6. Try new Mediums
7. Stick Stuff
8, Draw Frames from Flms
9. Pick an Animal
10, Do Finished Drawings
People 1've referenced In the 'Copy" Sectlon
Kasey golden, Jake Wyatt, Jake Parker 