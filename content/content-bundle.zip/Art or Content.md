---
dg-publish: true
# Metadata used for sync
id: "b677bb10-5445-11ed-8570-33ed70ff303d"
title: "Art or Content"
source: ""
created_date: "2022-10-25"
modified_date: "2022-10-25"
deleted: true
---
Art is born out of an extreme
sense of dissatisfaction.
To call it content goes against
the very idea of art.
An artist is never content.
Content is never art.
Choose what you want to create.
Art or Content. 