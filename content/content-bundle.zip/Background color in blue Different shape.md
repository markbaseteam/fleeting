---
# Metadata used for sync
id: "b4936200-7302-11ed-868a-9724eabee8f6"
title: ""
# Extracts all tags in content into the metadata
tags: []
source: ""
created_date: "2022-12-03"
modified_date: "2022-12-03"
deleted: true
---
Background color in blue
Different shapes choose purple color
How to customize brush into shape ? Search,
Yellow color for sketching
Texture brush like dull flat pencil for sketching
Search for shortcuts of copy and paste?
Technicalmpen?
Steam line in procreate?
Create new layer and insert it below steching layer and try adding colours to your shapes like bold pink . If you like you cam change opacity to lower. To increase thickness just add another shape like ellipse.
To see separation add outlines.
Automatic selection in procreate?
Now by above method it will only select background and not Badges so then  we can erase all the extra colour.
Now duplicate the shapes layers and add white background to it and then select gaussian blur
Use color fill after automatic?  9th video
To add shadows go to color layer and add clipping mask to it and now go to multiply mode.
To change the color of shadow use hue saturation and all.