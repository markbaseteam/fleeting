---
# Metadata used for sync
id: "e3610ab0-7302-11ed-868a-9724eabee8f6"
title: ""
# Extracts all tags in content into the metadata
tags: []
source: ""
created_date: "2022-12-03"
modified_date: "2022-12-03"
deleted: true
---
Barclay software bsd operating system

Software means set of programs plus operating procedure

Two kinds
System software means deals with hardware it provides platform for other softwares to run 

Application software means designed for specific task like vlc media and ms word

Writesystemcode

C languages written in windows, linux
Antivirus is system software

Process is running
State of program

Threads : a light weighted process it runs under the process

Process synchronization 
Critical region < waiting list

Deadlock condition 

2nd lecture :

To run program, it loaded in ram
How OS is loaded when we turn on computer.
OS is stored in ROM. BIOS : basic input output system is checking all hardware resources are like motherboard are working or not. Then, applying method on 
POST : purpose on self test like keyboard, mouse, CPU then ram starts and OS comes under RAM.
Bios Is responsible to execute OS

Need of OS:
System call is responsible for opening any doc, photo or app.
 professor is responsible for running code
OS is responsible to tell processor to run

OS manages memory and help multiple programs run simultaneously 

Schheduled processing?
Multi programming - only 1 process is executed
Multi tasking - multiple processing switching definitecamoiny of time
Mipulti proc4esing 

Multi tasking : specify time is there to execute for likoisc

Real time Os