---
# Metadata used for sync
id: "e709b3c0-51fa-11ed-a973-d1d096ecbb7a"
title: "Better Orator"
source: ""
created_date: "2022-10-22"
modified_date: "2022-10-22"
deleted: true
---
So, here are my 11 tips that will help you calm your nerves
and make you a better orator:

1. Small actions matter 
Most of the fear from public speaking comes from the
fear of disapproval.
So, take small actions every day that exposes you to a
tiny dose of fear of disapproval.
The steps can be as little as talking to a receptionist or
returning your food in a restaurant.
These steps will help you build immunity against the fear
of disapproval and take actions that were previously out
of your comfort zone.
It's a small concept but will make a huge difference.
2. Practice
Practice as much as you can. Talk to as many people as
you can.
Putting yourself out there is the only way you can grow.
Give speeches at home, videotape yourself, watch them
yourself, identify and jot down the mistake, work on them
or show them to your critique friend.
3. Nervousness is normal. Practice and prepare!

Everyone feels the physiological impacts like pounding
heart and trembling hands.
But this adrenaline rush that makes
you sweat also makes
you alert and ready to be your best.
Do not associate these feelings with the idea that you are
performing poorly; chances are the person doesn't even
care as much as you do.
The only way to overcome this anxiety is to practice and
prepare.
4. Engage with your audience.
When you are speaking, try to interact with your audience,
this will make you feel less isolated as a speaker and
make the speech more interesting.
Further, limit the use of words like "just", "actually", "I just
think that".
These convey a sense of submissiveness and reduce
your power as a speaker. Be direct and clear.
5. Talk slowly.
If you are nervous, then that might cause you to talk
faster.
Talk slowly as talking fast may cause you to fumble and
say things that you don't mean.


