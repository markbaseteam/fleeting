---
# Metadata used for sync
id: "53413660-5446-11ed-b946-2968f4beb22c"
title: "Bus travel Timepass "
source: ""
created_date: "2022-10-25"
modified_date: "2022-10-25"
deleted: true
---
Conduct thought experiments
Traveling by public transport offers many possibilities
to conduct Gedankenexperiment's or thought
experiments. For instance you could close your eyes
for a while try to attempt to deduce your current
location from other cues - like the number of turns the
bus takes, or if you travel on Indian roads, you can
even pinpoint your exact location from the pattern of
potholes & speed breakers you encounter. The
possibilities are only limited by your imagination.
Sherlock could access a mental map of London
complete with average speeds of a vehicle taking into
account the traffic on each street and chart out the
most efficient route.


Hone your deductive skills: It's a lot of fun to try &
emulate the fictional detective's methods while
commuting on public transport. You could observe
your co passengers' attire, age, behavior, body
language etc and attempt fantastic deductions à la
Sherlock Holmes. Every passenger is unique & they
come from all walks of life. This is much more fun if
you have your very own Watson - a friend with whom
you can compare ideas with. The conversation often
goes off on tangents & you're no longer bored.