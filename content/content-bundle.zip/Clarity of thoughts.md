---
# Metadata used for sync
id: "183ea530-520b-11ed-811f-e1b76e71d440"
title: "Clarity of thoughts"
source: ""
created_date: "2022-10-22"
modified_date: "2022-10-22"
deleted: true
---
The most important skill in 2022 is clarity of
thought. To have clarity of thought the most
important skill is writing. You don't have to be a
good or a bad writer.
Organise your thoughts by writing them down and
that will lead to clarity. Clarity will lead to a better
understanding of what you want and what you
don't want and that is better than most self-help
books in the world 