---
# Metadata used for sync
id: "972bc2b0-730d-11ed-a10e-f5afb13fb3e7"
title: ""
# Extracts all tags in content into the metadata
tags: []
source: ""
created_date: "2022-12-03"
modified_date: "2022-12-03"
deleted: true
---
Coao butter(mordt,2am,satvik organic),  refined (grinded) can also using icing sugerpar,sugar(50gms), cocoa powder(Hershey's,)(should be unsweetened)50 gms       microwave in 30 sec wise.
Coconut oil instead of coco butter 70 gms 
Bowl water small bowl inside it and keep butter at lowest flame double boiling it . Then add table spoon wise batch wise once powder once sugar, mix, again add once powder once sugar. No lumps 
Fine consistency.
1ź3 montgsvshelf life
E322 stabilize for transport tiny bit soy lecithin 
Air bubbles will be there so tap the mould, 
Keep fridge for about 30 min or 1 hourno deep freeze
Can add vanilla essence 
puirk- stabilizer company
Bo greasing before pouring 
Roasted dry fruits 




Food miniarure:
Air dry clay, polymer clay requires baking, cold polycene clay can also use
Thai clay, oil colours, old tooth brushes, cutters like bottle cap, fevicol, rolling pin! Talcott powder like ponds powder at last do varnish , acrylic roller, in ac dries faster. Take 5 to 6 hours to dry