---
# Metadata used for sync
id: "b4e954f0-5d2f-11ed-bbcd-c58743766a1e"
title: "Connections"
source: ""
created_date: "2022-11-05"
modified_date: "2022-11-05"
deleted: true
---
People find it hard to
make connections
because they're looking
for transactions

Also connections don't
necessarily have to be romantic.
You can have a connection with a
friend, a relative, a mentor
anybody.
I think the true test of a real
connection is let's say
hypothetically you end up killing
someone this person should still
be able to look at you with
empathy and try to understand
why you did that.
Someone whom you can be
yourself with and absolutely no
fear of judgment.


Easiest way to makea
long lasting connection
with someone.
You need to make an
effort to be vuinerable
with that person and
that person should be
able to be vulnerable
with you. This atleast for
me is the gold standard
for a deep connection

But to truly be vulnerable with
someone else, you have to
accept yourself first without
any judgement only then can
you allow others to see you
that way