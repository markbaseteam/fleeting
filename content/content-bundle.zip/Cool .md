---
# Metadata used for sync
id: "80287790-5461-11ed-86d1-6571f6afd646"
title: "Cool "
source: ""
created_date: "2022-10-25"
modified_date: "2022-10-26"
deleted: true
---
Dagobert Renouf @dagorenouf
The more I work on my startup, the less
scared I am that somebody will steal my idea.
Because I know how hard the execution is
anyway


someone once told me "if you stress
oo much about something before it
appens, you basically put yourself
hrough it twice." And I feel like
omeone needed to hear that too, be
appy


Motilal Oswal@MrMotilalOswal
Thelped a man climb a mountain and foun
that I too had reached the top. - Unknown