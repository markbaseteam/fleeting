---
# Metadata used for sync
id: "c3bba950-5461-11ed-b427-0ff5f9d449ce"
title: "DM in Insta answer"
source: ""
created_date: "2022-10-25"
modified_date: "2022-10-25"
deleted: true
---
edgar allan.hoe Lol instead of writing
everyone to check dm why dont you write
the price in caption itself?? Are you giving
different costs to everyone? Like wtf?
thegoofystore.in @edgar._allan.hoe
I know right, I will tell you why we
do that, because most of the times,
when people ask for price, they just
don't wish to know the price but
usually have some other queries too,
hence we DM them and try to help in
any way possible.
edgar. allan.hoe @bhasadh_ yes but
knowing the price just in the caption
would be very easy for all of us. As
you can see, most of the comments
are about price, so if you could just
mention it, and if it's in our budget
we will obviously DM you for other
queries or placing the order?




You did not dream to become average
when you were a kid, WHY settle now?