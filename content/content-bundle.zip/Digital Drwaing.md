---
# Metadata used for sync
id: "6d131430-4958-11ed-8c69-018bdb7298bb"
title: "Digital Drwaing"
source: ""
created_date: "2022-10-11"
modified_date: "2022-10-11"
deleted: true
---
Color theory, lone work, shadows, anatomy, etc.
Fundamentals are key. Don't work on trying to make
masterpieces except for progress checks every now and


I completely agree. Honestly, they need to work on 3D
forms, shape language, line quality, and proportions
before even tackling color. Drawing is a marathon, not a
sprint. You're going to put out A LOT of bad drawing

Also, you might try using more saturated colors in your
work if you're trying to go for that kind of "pop".
Try to Learn the fundamental shapes and forms
Practice anatomy, perspective and widen your visual
storage. I believe that this advise works with any kind of
art...regardless the style.

For some tips..maybe try using more edgey forms to draft
the whole drawing before going into round details. Circular
forms are much harder to determine the shape than
squares and triangles.


Their characters eyes are clearly defined with prominent
hooded eyes. They breaks hair down by value rather than
by strand. They ops out of using heavy detail where not
needed like in the teeth. They use highlights sparingly.
Every character has flushed lips and cheeks. The shadows
in their characters have a very very slight blue tint. The
skin tones are full of pinks and yellow.


Practice without knowing what you're practicing is
ineffective. OP needs to basically do a masterstudy if
he wants to emulate this style.


Agree with emphasis on the "work on it until you love
it". Don't just call something a failer and move on to the
next thing. Come back to it tomorrow and erase what
seems off to try again.


Something that helps me whenever I see art I like, try
emulating in sections. Rather than looking at a whole
piece that you live and trying to emulate something similar
break it down one at a time. If you like the eyes, what
about the eyes is it that you like? The shape, where the
lash line is thickest, the iris size, the shading, etc? Once
you can pin point an area of focus, it becomes easier to
grasp without getting overwhelmed and lost in the overall
detail. Just pay attention to all the detail in an isolated
area.
Focus only on recreating a piece at a time rather than a
whole picture at once. Isolating areas can really break
down aspects of what you like when you cant quite put
your finger on it. This is at least how I learn best.


https://youtu.be/lhXwGYlI1 vIA this guy talks about it, I'm
recalling more of an anime style but no clue how to find it

It looks like you are using black and white for shadows/
highlights, try using compliments of each other with
colors, like purple and yellow or blue/orange on like a
multiply layer.


Colored line art, and a softer blend between shadows and
light! Also, your line art is pretty consistent and a bit too
thin, while theirs is weighted in some places and has a
thicker side to it


AISU, COIISIUEI ZUUITIIIY II aIu iealy sluuy iov uIey 1E
shading and lighting!! You can set your layers to Overlay
for lights and multiply for shadows, and just use black and
white on them to bring out the colors you want using your
base flat :))
Another thing you might want to try is adding streamline
to your brush so you can make longer lines and have them
come out smoother, easier and more natural!


grey. It all adds up. l'd suggest Sinix on YouTube for
some really great tutorials about how to incorporate
colour and make realistic shadow, especially this one:
https://youtu.be/ZJklaMECW6c

A few things to point out. In the first drawing the overall
drawing is very nice. I think the character (I assume
it's link?) had good proportions. However,I think the
colors are a bit desaturated and washed out/not enough
contrast. Make a layer on your drawing program that is
grey and use a layer mode to make it grey scale so you
can see the contrast. You want the grey tones to not be all
similar shade of grey. Also be sure to work on the folds
of the hoodie and the anatomy. His hands look flat and the
guitar also is flat because it isn't in any perspective. But
like I said, it's a nice illustration regardless of it's flaWs, just
need to work on a few things.