---
# Metadata used for sync
id: "49db5340-7303-11ed-868a-9724eabee8f6"
title: ""
# Extracts all tags in content into the metadata
tags: []
source: ""
created_date: "2022-12-03"
modified_date: "2022-12-03"
deleted: true
---
Duplicate illustration
In top of that color it with white
Then use wand and select it
Then choose expand option and choose size
After that color it

First do protectvalpha on duplicate 
Then color it white
Remove protect alpha
Go to magic wand tool on white color layer only
Then draw selection boundary option
Then deselect it