---
# Metadata used for sync
id: "9f4f31c0-6f8e-11ed-a3ee-e9fa0d462aff"
title: "Eng always often "
# Extracts all tags in content into the metadata
tags: []
source: ""
created_date: "2022-11-29"
modified_date: "2022-11-30"
deleted: true
---
100%
always
85%
usually
75%
frequently
60%
often
50%
Sometimes
40%
occasionally
30%
rarely
20%
seldom
10%
hardly ever
0%
never

He always gives flowers to Mary.
I usually take two buses per day.
She frequently goes to the park
We often miss the English class.
They sometimes play soccer until the night
I occasionally travel by work
You rarely mixture friendship with business
He seldom lends something
We hardly ever play videogame
I never go out without money.