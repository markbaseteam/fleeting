---
# Metadata used for sync
id: "6fa2d1b0-4956-11ed-afc7-a9e231e7b21c"
title: "Family Treasure"
source: ""
created_date: "2022-10-11"
modified_date: "2022-10-11"
---
Family Treasure
1) Get a blank book
2) Ask each family member over 50
to write down life advice that their
descendants in 500 yrs should know
3) Keep passing it down
You now have a family treasure that
gets more useful Over time.