---
# Metadata used for sync
id: "8e00b100-5445-11ed-b3d0-9d8929337025"
title: "Feelings by Varun Mayya"
source: ""
created_date: "2022-10-25"
modified_date: "2022-10-25"
deleted: true
---
Trust your feelings!"-But feelings are nothing
final or original; behind feelings there stand
judgments and evaluations which we inherit in the
form of.. inclinations, aversionsThe inspiration
born of a feeling is the grandchild of a judgement-
and often of a false judgment!-and in any event
not a child of your own! To trust one's feelings-
means to give more obedience to one's grandfather
and grandmother and their grandparents than
to the gods which are in us: our reason and our
experience.
-Friedrich Nietzsche 