---
# Metadata used for sync
id: "42a9dc20-4fb0-11ed-9b89-1dc3e8fe4b0c"
title: "Find happiness quickly by varun agarwla"
source: ""
created_date: "2022-10-19"
modified_date: "2022-10-19"
deleted: true
---
How to find some happyness
quickly
Step 1
Let's say you're not happy with your
current life. To change your mind
about your current reality here's a
quick framework
First accept your current reality. I
hate my job but it's ok. Im not in a
great relationship but it's ok. I
haven't done much with my life but
it's ok. I have a lot of issues from
the past but it's ok.
You have to accept your current
reality without any judgment. This
is very important to reset your
mind. You have to tell yourself
you're in this situation but it's ok.


Step 2
Accepting your current reality
without any judgment helps your
mind process things better and
find solutions that work for you.
Remember your mind is an
incredibly powerful machine so it
can figure things out you didn't
even know it could.
So once you accept your current
reality you need to ask yourself
which one situation you want to
change first and you'll be
surprised how it will work it out for
you.
But for your mind to do the albove
the secret is accepting your
currently reality without any
judgement

For me this worked in the most
extreme situation
When I lost my brother I was in a
state of shock for like 2 weeks. My
mind just didn't work and I just
couldn't process anything.
So when l accepted the reality and
that this has really happened and
did that without any judgment my
mind took over and figured out the
next steps. And I was finally able to
handle to the whole situation.
I still look back and sometimes get
surprised. But that's how powerful
the human mind is.



I know I don't put these up as posts but
that's maybe because I like stories
better because I can express myself
better.
I don't want to post this on Twitter or
wherever. I know if I simply put these up
as posts my follower count will
quadruple because Insta stories doesn't
increase followers. Honestly my
follower count hasn't increased in 2
years andI don't care.
Ido this because I really like writing
about this and maybe it can help
someone here who's going through the
same.
If I make this about increasing my
follower count all of this content will
lose its authenticity because then it will
become about the outcome of more
followers.
So pls let's keep all this content written
and only on stories:)
