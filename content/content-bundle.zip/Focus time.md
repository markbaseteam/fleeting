---
# Metadata used for sync
id: "75996650-54d8-11ed-afd8-e33df88a34e7"
title: "Focus time"
source: ""
created_date: "2022-10-26"
modified_date: "2022-10-26"
deleted: true
---
Stare into space often and
long enough. Think of nothing. You won't lose the
planet or us. Everything will still be here when you
come back.

attention, they have power Over our time, our
ideas, and most importantly, our thoughts. Take
back your attention from everyone and give it to
the small crack on the street or to the boiling of
Waier or to a painting on the wall. Let go of the
need to be somewhere or do somethina. Take
back the power everyone else has on you by
paving attention to the negative space in our
World. There is some beauty in there.

If life needs creativity and fortitude, it also needs
us to pause and idle. This is how everything
works. Not doing anything is an act of great
rebellion. It is also an act of self-care. 
Because and the asteroids. Your value as a human being comes from simply existing
 You only have to be kind enough to
yourself to feed your soul whatever it needs.
Whether it be excitement or idle or routine. Allow
yourself to experience your life fully as the grand
spectrum that it is.