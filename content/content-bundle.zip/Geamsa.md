---
# Metadata used for sync
id: "359f28a0-72ba-11ed-81fa-57e94c379746"
title: ""
# Extracts all tags in content into the metadata
tags: []
source: ""
created_date: "2022-12-03"
modified_date: "2022-12-03"
deleted: true
---
1. Blow the cup - Starting blowing the balloon once the countdown starts and push the ballon till the end the first one to make it reach the finish line wins the game.
2. Pull the cup : Fill the cup completely with water and Pull the cup using a tissue roll towards you the first one to do so

3. Board football - You can buy it from amazon (Fast Sling Puck Board Game)
4. Towel race - Sit on the towel and drag it till the finish line without using your hands.
5. Pillow Smash - Fill your mouth with water (be careful not a lot) use a soft pillo smash your opponents face till one spills the water out.
6. Bottle cyclone - Tie a 1/3rd filled water bottle with a thick thread from a fan and stand in a circle blindfold, dodge the bottle, the last one to not get hit with the bottle wins.
ENJOY PLAYING