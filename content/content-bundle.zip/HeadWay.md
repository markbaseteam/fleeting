---
# Metadata used for sync
id: "ee39a350-54d7-11ed-afd8-e33df88a34e7"
title: "HeadWay"
source: ""
created_date: "2022-10-26"
modified_date: "2022-10-26"
deleted: true
---
Idealists are also called intuitive feelers.
They are concerned about their personal
growth and understanding of themselves
and others. They deeply value integrity and
authenticity in relationships and people.

Introverted, Sensing, Thinking, Judging
(ISTJs) are hardworking, trustworthy,
traditional, and cautious.

Introverted, Intuitive, Thinking, Judging
(INTJS) are perfectionists who love driving
themselves and others to do things inna
certain way.

"I have urged that they seek employment in
(1) the field and (2) with the kind of people
they would select, if they had no need for
money," Buffett wrote.