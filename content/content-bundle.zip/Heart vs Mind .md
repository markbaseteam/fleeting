---
# Metadata used for sync
id: "1a325ce0-4fb0-11ed-9b89-1dc3e8fe4b0c"
title: "Heart vs Mind "
source: ""
created_date: "2022-10-19"
modified_date: "2022-10-19"
deleted: true
---
Will I listen to heart or
mind?
You "listen" to who "speaks".
The mind gives youa solution on the
basis of information that you have
gathered by taking care of
consequences.
But the heart's role in our body is just
to pump the blood. So let it do that
work and don't include it in the
thought process, it literally has no
role in the thought process.
It's just the mass and the media who
exaggerated the role of heart.
Thought process includes memory and
consciousness, not a pumping organ 