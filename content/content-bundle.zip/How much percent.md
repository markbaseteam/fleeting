---
# Metadata used for sync
id: "6783b4e0-54d7-11ed-afd8-e33df88a34e7"
title: "How much percent "
source: ""
created_date: "2022-10-26"
modified_date: "2022-10-26"
deleted: true
---
Q11104/27759 0.4000144097

I've been alive for III04
days, and based on life
expectancy, I anm 40%
exactly today!!