---
# Metadata used for sync
id: "3aee87f0-4fb1-11ed-8c92-818f9219fcc0"
title: "How to think creatively"
source: ""
created_date: "2022-10-19"
modified_date: "2022-10-19"
deleted: true
---
How to think creatively?
(From ideas on demand)
Imagine that the below
Roman equation is created
using movable sticks.
It reads as, "11 plus 1 equals
10," which is obviously
incorrect.
XI+1= X
Your challenge is to correct
the equation by moving the
least number of sticks
without touching plus or
equal signs. How many
sticks do you need to move?


Most of y'all said 1 stick. That's
not the right answer. But
remember this is creative
thinking and not logical thinking.
Now pls Iook at the equation
again:)


Some of you finally got it.
The answer is O sticks
because if you hold the
phone upside down the
equation automatically
corrects itself.
And as you can see every
problem can have numerous
solutions if you look at it
creatively.
Creative thinking will be the
most important skill of the
next 10 years:)
