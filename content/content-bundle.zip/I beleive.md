---
# Metadata used for sync
id: "da0624b0-5461-11ed-a334-d5baa6470bfd"
title: "I beleive"
source: ""
created_date: "2022-10-25"
modified_date: "2022-10-26"
deleted: true
---
You don't need talent or skills, you
need the discipline to challenge
yourself every day.


Imo the biggest behavioral change in most
people is saying "no" to anything they aren't
interested in.


Being smart is a
good thing but never
be so smart that you
don't allow your brain
to learn more.

Learn to listen to your
child as much as you
expect them to listen to
you

If they cannot meet
your standards,
don't lower your
standards so that
they can.

Every time you clean
something, you need to
make something else dirty.

When you're not used to getting
your needs met, prioritizing yourself
feels selfish.

That's the difference between knowing' and 'understanding'.
You know a lot of sensible things, but the reason why you don't apply them is
because you don't understand them. To understand something, it must come
from the reasoning of your own mind. Knowledge can be borrowed, but you
can't borTOW understanding. 

rajshamani What are you most obsessed
with?
anantladha1234 So true. Balanced life
can only give balanced results.
8 likes Reply
rajshamani @anantladha1 234
always saying the best things sir