---
# Metadata used for sync
id: "2e24b260-754a-11ed-9ad2-b9e484f01e22"
title: ""
# Extracts all tags in content into the metadata
tags: []
source: ""
created_date: "2022-12-06"
modified_date: "2022-12-06"
deleted: true
---
If I tell you my idea, you will steal it.
A lot of people feel that if they talk about their ideas someone will steal it.
Let me clear this: NO ONE IS
STEALING from you.
- if someone has the will & resources to copy they will copy even after you built it first. And if someone doesn't have the ability to copy they will only talk about it, won't do shit about it.
- don't hold yourself back and share as much as you can about your ideas because that's how the right people will join/help/ support/challenge you. The more you talk the better the support and criticsm you get, in both the cases you will win.