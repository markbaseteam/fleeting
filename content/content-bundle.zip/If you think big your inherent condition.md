---
# Metadata used for sync
id: "c4bd61f0-6e78-11ed-8b4b-ab24cd10496e"
title: ""
# Extracts all tags in content into the metadata
tags: []
source: ""
created_date: "2022-11-27"
modified_date: "2022-11-28"
deleted: true
---
If you think big your inherent conditioning of perfectionism and fear of failure will further prevent you from getting started

The best way to start small is using the Cristopher
Columbus technique.
The guy just wanted to find a sea-route to India.
That's it. Nothing more. In the process he was one of the people who discovered America and changed the world as we know it