---
# Metadata used for sync
id: "4db03770-60d8-11ed-9d60-bf435be3aa22"
title: "Illustrations niyes"
source: ""
created_date: "2022-11-10"
modified_date: "2022-11-10"
deleted: true
---
1. Place your sketch layer or lineart layer on top
with a white backgrOund after completing your
artwork.
2. Erase it as shown in video and reveal your fully
shaded illustration lying below it.

What brushes do you use?
lusually use custom Procreate brushes. Dry ink is
my favorite one. Honestly, I can drawall
illustration with this only one brush
And also for details I use some brushes that I got
from my favourite artists.
Here're my tav brushes

Chalk, Procreate
for the rough sketch
Studio pen Procreate
for the flat coloring
Dry Ink, Procreate
for the clear sketch
Oberon, Procreate for texture
Spectra, Procreate
for the shadows
Soft Brush Grain,
Sara Faber
for the blush


And can you plz tell me best
brushes for sketching coforing
shading & texture in ibis paint
It totally depends on your att
style, uhat you want in your
IClustrations
Dip pen hard, flat watercolor mix,
felt tip pen soft (for coforing)
Pencil 1/ Coarse pencie ( for
sketching)
Airbrush normal (for shading and
hightights)
Gouache Opaque (for texture)