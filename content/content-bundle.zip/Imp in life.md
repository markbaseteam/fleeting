---
# Metadata used for sync
id: "0c7c9890-6fd6-11ed-a84d-1fef11c365ee"
title: "Imp in life"
source: ""
created_date: "2022-11-29"
modified_date: "2022-11-30"
deleted: true
---
Show people your
personality, perspective, mindset, aesthetics, style, choices, taste, preferences, skills, information, attitude etc. & let them fall in love with you for that instead of your possessions.


15.Feeling that you don't belong somewhere is the best thing that can happen to you. This means you can finally know what your true passion is

"If I love myself, despite my infinite faults,
how can I hate anyone at the glimpse of a few faults?"

3. Being comfortable is the worst thing you can do to yourself. Adjust to chaos if you want to achieve big things.

Wanting a good lifestyle for yourself is not a bad thing. Never be ashamed of owning up your dreams

No matter what, remember that you are still young and can change your career the day you want to.

Most people loose their identity just to fit in
the group only to realize it wasn't worth it.

God has perfect timing; never early, never late. It takes a little patience and it takes a lot of faith but it's worth the wait.

Success doesn't mean winning one game
Success means living life on your terms for a really long time.

Don't feel guilty if you can't balance everything in life. A 50-50 balance is a myth when you are obsessed with your mission.

11. What matters is not that you make the best efforts but that you make them daily. That is the only thing that shows results.
12. Everything gets boring after a certain point.
What matters is how you find interesting ways of doing it everyday.


We plan so much that we forget that the actual problem gets solved by taking action.
We are always trying to perfect our plan without even trying an inch of it.

Man is disturbed not by things, but by the views he takes of them.
#epectetus


The past explains how you got here.
But it doesn't determine where you go from here.

When it is obvious that goals
Cannot
be
, reached,
Don't adjust the goals,
Adjust
the
action
steps.
•Confucius

Always go with the choice that scares you the most, because that's the one that is going to help you grow.

"If you spend enough time with anything, you start liking it, even sadness."
- Raavan: Enemy of Aryavarta
- 
"Discovering the unexpected is more important than confirming the known." - George E. P. Box,

"Sometimes, truth causes pain and suffering.
At such times, silence is preferred."
- Ram: Scion of Ikshvaku
- 
- "Be clear about what you want.
But hide it well. It will help you get what you want."
- Raavan: Enemy of Aryavarta
- 
- 
- 

The secret Of Your Future is Hidden In Your Daily Routine


"All courses of action are risky, so prudence is not in avoiding danger (it's impossible), but calculating risk and acting decisively.
Make mistakes of ambition and not mistakes of sloth.
Develop the strength to do bold things, not the strength to suffer."
Niccolò Machiavelli