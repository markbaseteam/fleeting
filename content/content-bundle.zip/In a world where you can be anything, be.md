---
# Metadata used for sync
id: "d23c6d90-5cf2-11ed-9e7d-e157b239975e"
title: ""
source: ""
created_date: "2022-11-05"
modified_date: "2022-11-05"
deleted: true
---
In a world where you can be anything, be a little extra. Extra in everything you do.

THAT'S when I realized, that if I want to be successful, I have to depend on myself not the people around me.

Do something instead of killing time, because time is killing you. Paulo coelho