---
# Metadata used for sync
id: "4eb27240-730d-11ed-a10e-f5afb13fb3e7"
title: ""
# Extracts all tags in content into the metadata
tags: []
source: ""
created_date: "2022-12-03"
modified_date: "2022-12-03"
deleted: true
---
Is it ok to be unproductive
two consecutive weeks?
haanji, but if you wanna be nproductive toh dhang se
ho. don't halfass unproductivity by wondering if it's
okay or not. Take a week or two of£ and clear your head
in and out. When you 're done with that, then maybe
figure out why you feel the need to take such a long
rest period in the first place. Is it because you have
unrealistic expectations of productivity? analyse your
habits and malke some tweaks so you don't burn out
yourself like this again and again