---
# Metadata used for sync
id: "2808d450-6f1f-11ed-ae42-5188857e36b5"
title: ""
# Extracts all tags in content into the metadata
tags: []
source: ""
created_date: "2022-11-28"
modified_date: "2022-11-28"
deleted: true
---

"It doesn't make sense to read something unless you can absorb the information and apply it to your daily life."
- Jim Kwiker) 