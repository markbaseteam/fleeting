---
# Metadata used for sync
id: "65b1a150-5445-11ed-a33f-4976dfe4612a"
title: "Journaling aporoches"
source: ""
created_date: "2022-10-25"
modified_date: "2022-10-25"
deleted: true
---
Keep a Story Journal
A story journal will help you keep track of
your stories. Remember these points for a
good story journal
Don't write in a paragraph - write just
bullet points.
Feel the tiny details - don't have to
write- you will remember them each
time you see the bullet points.
If possible give the stories a name and
where you can use them.
The story may be normal for you butit
is life-changing for someone. So don't
judge a story - if it had emotion -just
write it down.



Journaling approaches
The Gratitude Journal: Simply write
about something that you're grateful
for
Morning Pages: Before starting work
each day, write 3 pages, long-hand, of
anything that crosses your mind, to
clear your head.
The Goal Journal: Incorporating your
goals intoa daily journal is a huge step
to getting them done.
The Values Journal: Identify the values
that are important to you. Then write
about how the events of your day
connect back to your values.
The Curiosity Journal: Challenge
yourself to write about one thing every
day that made you stop and aska
question.