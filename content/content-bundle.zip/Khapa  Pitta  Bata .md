---
# Metadata used for sync
id: "1f396fe0-6800-11ed-a45a-fdf258645066"
title: ""
source: ""
created_date: "2022-11-19"
modified_date: "2022-11-24"
deleted: true
---
Khapa 
Pitta 
Bata
