---
# Metadata used for sync
id: "f7d0cd60-6c85-11ed-96ba-353e1b31f947"
title: "Korean words"
# Extracts all tags in content into the metadata
tags: []
source: ""
created_date: "2022-11-25"
modified_date: "2022-11-28"
deleted: true
---
Namaste WAE - Why
YEOBOSEYO - Hello On the phone
OEMMA AND APPA - MOM AND DAD
JUSEYO - PLEASE
DAEBAK - THATS AWESOME
