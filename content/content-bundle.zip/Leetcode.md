---
# Metadata used for sync
id: "f7673f10-520b-11ed-9e30-cd9f4b6ba1ff"
title: "Leetcode"
source: ""
created_date: "2022-10-22"
modified_date: "2022-10-22"
deleted: true
---
DON'T MISS
THE CONTESTS
After solving 50-60 mediums start
participating in contests Held
under "Contest" tab
Helps you assess your ability to
come up with your own solutions
Boosts your confidence
Creates real interview scenarios
under time constraints
P.S:If you solve 75% of contest questions,
consider yourself decently prepared


WARM UP WITH
EASY LEVEL QNS
Solve 30 to 40 questions for
understanding > implementation + approach
Solve upvoted problems, witha
ratio of 4:1
Brush up your basic coding skills
by solving easy problems.
If you are an absolute beginner,
don't skip easy level
P.S: Get out of easy phase asap,
Mediums are mostly put in tech
interviews