---
# Metadata used for sync
id: "4faf7f70-4956-11ed-afc7-a9e231e7b21c"
title: "Life Hacks"
source: ""
created_date: "2022-10-11"
modified_date: "2022-10-11"
---
Keeping your Cool
"If someone insults you during a
meeting, pretend like you didn't hear
them the first time.
Politely ask them to repeat
themselves.
They'll either repeat the insult and
look rude or realize their mistake and
apologize."


Airplane Mode Hack
"If you're stuck on an annoying call,
put your phone on airplane mode
instead of hanging up.
The other person sees "call failed"
instead of "call ended".


