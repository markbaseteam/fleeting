---
# Metadata used for sync
id: "3aafe060-54d7-11ed-afd8-e33df88a34e7"
title: "Like and love"
source: ""
created_date: "2022-10-26"
modified_date: "2022-10-26"
deleted: true
---
If you like a flower you cut itoff from tree but,
if you love that flower you water it and let it grow
That's the difference between like and love 