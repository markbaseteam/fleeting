---
# Metadata used for sync
id: "ab58b640-7302-11ed-868a-9724eabee8f6"
title: ""
# Extracts all tags in content into the metadata
tags: []
source: ""
created_date: "2022-12-03"
modified_date: "2022-12-03"
deleted: true
---
Literature by curiosity stream
Hyperbole : exaggatered statements or claims not meant to be taken literally
Metaphor : a figure of speech in which a word or phrase is applied to an object or action to which it is not literally applicable

Read critically to understand the feelings and act empathetically and know various symbols
Verona Italy juliet place
Hazel and Augustus
John keep author check
Iambic pentameter 
Iamb is a poetic foot consisting of a stressed syllable and an unstressed syllable
Pentameter menaing that there are 5 feet in a line