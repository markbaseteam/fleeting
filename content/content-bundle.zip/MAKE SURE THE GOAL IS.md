---
# Metadata used for sync
id: "090f0630-60da-11ed-acf6-1fcbf039a4c5"
title: ""
source: ""
created_date: "2022-11-10"
modified_date: "2022-11-10"
deleted: true
---
MAKE SURE THE GOAL IS
ATTACHED TO A LIFE VALUE.
Values are not the same as goals.
Imagine you're sailing a boat on the
ocean. Goals are like the islands on the
horizon that you're traveling towards.
Values are like the North Star that
points you in the right direction.
Ask yourself whether
your goals are based on
your larger life values. If
not, make some
adjustments.
If your goal reflects a value you hold
deeply, you're more likely to be
successful than if your goal is just
another "should" to check off on your to-
do list.