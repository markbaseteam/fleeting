---
# Metadata used for sync
id: "0044a960-6193-11ed-bf58-417dffeb37a3"
title: "Mac keys ideas"
source: ""
created_date: "2022-11-11"
modified_date: "2022-11-17"
deleted: true
---
Option + escape = speak selection
Control + swipe up on mouse = zoom
