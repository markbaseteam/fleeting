---
# Metadata used for sync
id: "1ad4eb00-520c-11ed-a07e-3db8be41d93e"
title: "Manifestation"
source: ""
created_date: "2022-10-22"
modified_date: "2022-10-22"
deleted: true
---
HOWTO MAKE
YOUR WALLETA
MONEY MAGNET

3. Keep your notes organised - They should always
be facing in the same direction and never be
folded. Place them in yale ordertbney
Additional tip - While giving out money to someone,
always fold the note towards you and chant - I
attract more money than I give. 
 