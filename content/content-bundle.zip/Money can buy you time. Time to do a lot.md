---
# Metadata used for sync
id: "c4a885f0-6bfd-11ed-af4b-8b5708ec0dee"
title: ""
source: ""
created_date: "2022-11-24"
modified_date: "2022-11-24"
deleted: true
---
Money can buy you time. Time to do a lot of things you always wanted to do.

But money can never buy you back the time you spent chasing all that extra money you never needed :)

There's no point negotiating if you don't have leverage