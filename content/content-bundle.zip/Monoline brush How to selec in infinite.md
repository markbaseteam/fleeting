---
# Metadata used for sync
id: "bb9beb80-7302-11ed-868a-9724eabee8f6"
title: ""
# Extracts all tags in content into the metadata
tags: []
source: ""
created_date: "2022-12-03"
modified_date: "2022-12-03"
deleted: true
---
Monoline brush
How to selec/ in infinite painter an resize

Reference option on layer
Color apalatte

Making outline by adding background whither layer under inking layer and drawing outlines plus filling them.

Duplicate the outline layer and start filling black in that. Lower outline layer and then increase gaussian blur and move the layer to adjust shadow if you think it is to much then reduce opacity.

To add texture create a layer on color layer and select cygnet texture brush with gray color. Now select outline layer and select that layer by viwing options  and add texture to it. By coloring it.
Now create under layer which si texture 2 and select white color and color it 
And clear select on outline layer.
On 2nd texture use layer burn and on 1st texture use color burn

Search paper texture brushes