---
# Metadata used for sync
id: "36f92e80-51f9-11ed-bef6-b75e6ea918ad"
title: "Moral Stories"
source: ""
created_date: "2022-10-22"
modified_date: "2022-10-22"
deleted: true
---
A father was busy reading his favourite magazine
and his little daughter was every now and then
distracting him.
To keep his daughter busy, he took out one page on
which the World Map was printed. He then tore the
page into pieces and asked her to go to her room
and put them together again.
Having done this, the father was now convinced he
would read his magazine without any disturbance
as it would take his daughter the whole day to get it
done.
But the little one came back within two minutes with
the perfect map. !
could do it so quickly??
She giggled and said,
"Oh..Dad, there is Amitabh Bachan's photo on the
other side of the paper, I made His face perfect to
get the map right.!
Moral of the story:
In life there is always the other side to whatever you
experience.
When ever we come across a challenge or puzzling
situation,
look at the other side, you will be pleasantly
surprised to find an easy way to tackle the
problem..! 