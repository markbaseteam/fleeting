---
# Metadata used for sync
id: "7bafca70-4fb0-11ed-8fae-ebffd89300f4"
title: "Morning vs Night Person"
source: ""
created_date: "2022-10-19"
modified_date: "2022-10-19"
deleted: true
---
Good morning
I have now fully transitioned from a
night owl to a morning person.
Is there any major difference?
No
Has my productivity increased?
No
Have I been able to to think better or
differently?
It's the same
Is morning better or the night ?
For me both are the same. Earlier I had
peace in the nights to work on stuff
and now it's the early mornings.
Conclusion
Doesn't matter if you wake early or
late. Only matter who you are and what
you seek :)

In terms of eating my meals
have shifted by 2-3 hours.
Honestlyl think the only
thing that matters isif
you're stress free. Even if
you wake up early and work
out regularly but if you're
always stressed then I don't
how much that will help.
A clear and a peaceful mind
is what I've found is the best
solution.

And 9 hours of
uninterrupted peaceful
sleep.
Except for my depression
years I've always slept for
8-10 hours every day.
I'm 35 now and I safely tell
you one that 6-8 hours of
uninterrupted sleep in the
best thing in the world:)


No difference at all in terms
of happiness or mood. I was
happy asa night owl and I'm
happy as a morning bird.
It may be subjective but
from what 've seen -
happiness and mood is a
function of your state of
mind and not the time you
wake up:)


Another answer



Night is not for study
it's only for sleeping??
Is it right9
Yrr dekho sab ki apni apni
| strength aur tarike hai.
But usually, human beings become weak emotionally
during night time (2-5). Try it, if you wanna build
trust, or know someone's secrets that they don't tell
easily, talk with them in between 2-5am.
Tumhe kya lagta hai, bande bandi raat bhar yuhi chat
krte hai. There is a psychological reason behind that.
|But in yogic culture, it's a boon for a Sadhak, because
the energies are in reverse direction. So if you get
trained in the reverse flow, you will easily master every
flow of life.
Remember Sachin and Bradman used to practice with
heavy bats so that when they actually play, they have a
good control over a lighter one. 