---
# Metadata used for sync
id: "a87452f0-5461-11ed-8b7f-c771449ecb7e"
title: "Moti"
source: ""
created_date: "2022-10-25"
modified_date: "2022-10-25"
deleted: true
---
YOU DON'T HAVE TO
START STUDYING ATA
ROUND NUMBER, YOU
CAN ALSO START AT
7.26


You're probably constantly worrying
about the next part of your life without
realizing that you're right in the middle
of what you used to look forward to.


Be scared, and do it anyway.
Be under-qualified, and get in
the room anyway. Be messy,
imperfect, and unsure and
show up anyway. Comfort is
the enemy of growth. Get
uncomfortable.


"To measure the quality of your life,
simply do nothing, and see how it
feels."
On pointX
Bhaisahab raat ko guilt ke
thappad padte hai agar din me
kuch nahi kiya.


Just read this somewhere
and it's a great way to start
your week
If you do something for
yourself, you'll always be
consistent
If you do something to
please others, you'll never
be consistent