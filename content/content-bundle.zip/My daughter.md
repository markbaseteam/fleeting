---
# Metadata used for sync
id: "8da575c0-5502-11ed-8043-d3f6c74b2aab"
title: "My daughter"
source: ""
created_date: "2022-10-26"
modified_date: "2022-10-26"
deleted: true
---
shethepeopletv "My daughter, Anaaya, was visiting her
grandparents in Vadodara for her vacation. When it was
time for her to return home, my dad suggested that she
travel by flight alone. It was something I had also done as a
child. At first, I was a little hesitant. But then l did some
research on unaccompanied minor travel. And thought that
this would be a great experience for my daughter and would
make her more confident. Even Anaaya was a bit confused
and scared at first, but we were able to explain to her how
everything would work and then she was quite excited. So
we filled up all the paperwork and on 22nd March 2022 my
7-year-old daughter, took a flight all by herself. She didn't
even have a cell phone with her, so there was no way to
communicate with her once she was inside the airport.
When she finally landed, the air hostess accompanying her
called me and we waited for her at the gate. Anaaya was so
excited to have travelled all by herself. The first thing she
said after she met me was 'The flight was too short, next
time I want to go on a longer flight alone. As a parent, I was
very hesitant at first, but I think it is a great experience for
parents and their children. Before boarding her flight, I had
told her a list of things, like don't talk to any strangers, don't
take any food from them, the usual list all parents give their
kids. And she did just that, she was very cautious and calm.
Our children are much more careful and smart than we give
them credit for and after this, I can see how Anaaya is so
much more confident and independent.