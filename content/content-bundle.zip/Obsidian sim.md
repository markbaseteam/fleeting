---
# Metadata used for sync
id: "f201e140-51ea-11ed-8322-eb3b6b17601e"
title: "Obsidian sim"
source: ""
created_date: "2022-10-22"
modified_date: "2022-10-22"
deleted: true
---

Folder note plugin

---
I think as you get comfortable with Obsidian you'll
find that you will develop the context for your notes
within the notes themselves.
Linking between notes with [double bracketed
references|]
Include text from ![Note A#lmportant Point] into
Note B using transclusion
Use tags to identity topics and use tag browsing to
locate notes
Develop Maps of Content (MOCs) to point to notes
that relate to a concept or topic
Explore the Graph view (or use one of the plugins
that expands the graph's capability)
Use Obsidian's Search feature which is very flexible
Ihave very detailed file hierarchies, mainly becausel
want to make sure my vaults are always ready to be
searched outside of Obsidian, but I use the features
above to navigate and locate notes more than I look
through the folder/notes hierarchies.