---
# Metadata used for sync
id: "eee850c0-5451-11ed-be89-85e870f6b633"
title: "Obsidian tip"
source: ""
created_date: "2022-10-25"
modified_date: "2022-10-26"
deleted: true
---
1. Open the PDF from within Obsidian
2. Tap the kebab (three circles in a vertical line)
button in the upper right corner of the view pane
3. Tap "Share." The ioS share sheet menu comes up
4. Choose "Markup" from that menu. The PDF will
open full screen with the page thumbnails along the
left edge
5. Highlight/annotate/draw, etc, either with your
finger or with Apple Pencil
6. Hit "Done" in the upper left, and your annotations
will save on the PDF
**edit to say that this should work with a PDF or with
an image
Today I learned about the 'kebab' menu, previously
Ionly knew about hamburger menus. Now I'm
hungry.


Ispent a long time trying all sorts of apps and
ended up building my own because none of
them fit my needs.
T'm a programmer so a lot of my notes are tied
in with web bookmarks as references. I needed
a note taking app that gave me full text search
of the scraped web pages along with my notes.

6
works for you, it's helpful to list 1) your
notetaking use cases 2) devices.
For instance:
1. for notetaking use cases: I've found I usually
take notes for a) bookmarking a link on my
browser and then adding my notes
underneath b) creative notetaking, say,
when I'm walking c) jotting down meeting
notes