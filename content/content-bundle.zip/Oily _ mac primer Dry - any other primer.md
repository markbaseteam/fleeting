---
# Metadata used for sync
id: "ccfee8a0-7302-11ed-868a-9724eabee8f6"
title: ""
# Extracts all tags in content into the metadata
tags: []
source: ""
created_date: "2022-12-03"
modified_date: "2022-12-03"
deleted: true
---
Oily _ mac primer
Dry - any other primer
CTM primer
Colour correcting red ya orange se correct Kate hai
Active canes mein green color ka corrector
LA girl ka orange corrector 
Then concealer 30 number where colour correcter is applied
Beauty blender damp