---
# Metadata used for sync
id: "34363410-730d-11ed-a10e-f5afb13fb3e7"
title: ""
# Extracts all tags in content into the metadata
tags: []
source: ""
created_date: "2022-12-03"
modified_date: "2022-12-03"
deleted: true
---
One of our core needs is the need for recognition. As
long as we dont feel recognized we experience some
kind of fear that we are not enough. Social media owe
a big part of their success to the human craving for
validation, and it seems like we have forgotten what it
means to have true confidence.

Confidence is notabout looking strong and invulnerable.
Confidence is about being who you truly are with all
your imperfections because you are not so concerned
about what others think of you; you are more concerned
about what you think of yourself.

The insecure compete against other people, while
the confident compete against themselves.

Being confident doesn't mean we have to show
everyone how good we are; it means that we know we
dre enough without having the need to show off.