---
# Metadata used for sync
id: "99d7c010-51b4-11ed-8e82-2f3f0349a231"
title: "Overthink"
source: ""
created_date: "2022-10-22"
modified_date: "2022-10-22"
deleted: true
---
If you're overthin king right nowa
good way to reduce it is by using
Metacognition. Its basically an
awareness of one's thought
processes and an understanding
of the patterns behind them.
It's is a little more complex than
it seems but you can start by
analysing why you're thinking
what you're thin king and
stopping right there:)


Metacognition serves to
correct the wandering mind,
suppressing spontaneous
thoughts and bringing
attention back to more
"worthwhile" tasks.
Throughout this week I'll talk
more about metacognition at
exactly 10 30 pm everyday.
Hope it helps:)

