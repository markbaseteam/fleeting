---
# Metadata used for sync
id: "eaba3ad0-5209-11ed-83b3-1753911d44d9"
title: "Overthinking as profit "
source: ""
created_date: "2022-10-22"
modified_date: "2022-10-22"
deleted: true
---
Use your overthinking gift
to build out a business :)
Overthinking is a gift. If you have the habit of
overthinking then you have a natural gift of
storytelling and creating hypothetical scenarios.
This can be utilised to write books, stories, blogs
and can can honestly make you some good
money:)

@mytraveldiaryblog I was just thinking about this. Exact
same thoughts. I ama big time overthinker, but this
has helped me with my storytelling and writing skills.
Oh the things that i think of. uffff. working on showing
up more and letting go off procrastination.
varun760 @mytraveldiaryblog procrastinating is
more to do with deep subconscious belief. See the
self-awareness series I've made to know more