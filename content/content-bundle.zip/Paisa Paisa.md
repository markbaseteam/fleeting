---
# Metadata used for sync
id: "99c30a40-550f-11ed-819e-0b00b4c2f838"
title: "Paisa Paisa"
source: ""
created_date: "2022-10-26"
modified_date: "2022-10-26"
deleted: true
---
Paisa kamane ke liye paisa nahi chahiye.
Paisa kamane ke liye dimag and mehnat
chahaye, paisa badane ke liye
paisa chahiye.
Ask yourself, what is that one thing that you like and want
to pursue. Put in your hardwork and develop your skills
around it. Earn money from that skill and then invest. 