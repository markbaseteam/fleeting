---
# Metadata used for sync
id: "665f23c0-5463-11ed-a0f9-333c70979239"
title: "Parallel world"
source: ""
created_date: "2022-10-25"
modified_date: "2022-10-25"
deleted: true
---
I have created a parallel dream world for myself in my head.
It's very comfortable and full of hope. It's not like Disneyland
or a world of superheroes. But it's a reflection of how I wish
my life to be. And I often take an escape into this world when
the reality gets too ugly to bear. I know you might say that
I am running away from my problems like a loser. But no. I
know my realities. I know my problems. And I know my fight.
But sometimes, it gets just too heavy and complicated to even
accept. So I take that short escape into my imaginary, sweet
world. I visualize how happy I would be, what I will do for
myself and my people, and how amazing things can be. It
works like medicine on my tired soul. I get that belief back that
life still can be beautiful. I just need to work hard, and I can
live that dream in reality. You might call it weakness. But for
me, it takes great courage to see a beautiful dream when the
reality gets too ugly and too dark. So I am proud of myself for
still being brave enough to dream. I am proud of myself that
I refuse to give up. There will be that day. There will be those
things. And I will do everything I can to make it real. I have a
dream. You will see it one day. I will see it one day.
- Rahul Kaushik
Instagram and Facebook @TheMeltingWofis <Heart Talko 