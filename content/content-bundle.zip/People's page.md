---
# Metadata used for sync
id: "e36b2640-54d9-11ed-bc8e-5d280fc9ae71"
title: "People's page"
source: ""
created_date: "2022-10-26"
modified_date: "2022-10-26"
deleted: true
---
I'm currently working on this part and I want my people
index arranged by hOW important they are to me. Ive got
these subheadings currently:
1. New people (whol am exploring to see if we click)
2. Inner circle (people I trust and want to remain closely
connected to)
3. Outer circle (people I trust but prefer to see in person
which is only possible maybe once a year due to us not
living in the same countries)
4. The vast (people who I don't care if they come/go, but
are in my life for some loose reason)