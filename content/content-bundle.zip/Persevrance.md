- [ ] ![[Leetcode]]
- [ ] ![[Social Media Categories]]
- [ ] ![[100 Percent]]
- [ ] ![[Skillshare class]]
- [ ] ![[speech]]
- [ ] ![[thealiporepost Dont procrastinate livi]]
- [ ] ![[Up work clients]]
- [ ] ![[Manifestation]]
- [ ] ![[Clarity of thoughts]]
- [ ] ![[Obsidian sim]]
- [ ] ![[relationship trend]]
- [ ] ![[Overthinking as profit ]]
- [ ] ![[Better Orator]]
- [ ] ![[start up ideas]]
- [ ] ![[remembering tech or languave]]
- [ ] ![[pen pal]]
- [ ] ![[Are you Scared? ]]
- [ ] ![[gossip to make money]]
- [ ] ![[make time for emptiness]]
- [ ] ![[Persevrance]]
- [ ] ![[business experience]]
- [ ] ![[grief]]
- [ ] ![[The Growth Paradox]]
- [ ] ![[varun mayya post comments]]
- [ ] ![[car]]
- [ ] ![[varun 76o inst apost]]
- [ ] ![[nazar lag gaye]]
- [ ] ![[Moral Stories]]
- [ ] ![[ironic]]
- [ ] ![[You have to do this ]]
- [ ] ![[self awareness part2]]
- [ ] ![[Overthink]]
- [ ] ![[The apprentice Experiment]]
- [ ] ![[self awareness part 1]]
- [ ] ![[after death]]
- [ ] ![[Find happiness quickly by varun agarwla]]
- [ ] ![[Digital Drwaing]]
- [ ] ![[write in obsidian]]
- [ ] ![[soroow]]
- [ ] ![[self Discovery Thought of the day]]
- [ ] ![[ry [fileName I phrase to displayll]]
- [ ] ![[paraocdm]]
- [ ] ![[occupations deepstash]]
- [ ] ![[motivate new skills]]
- [ ] ![[emotionally over an dunder available]]
- [ ] ![[Story of your life idea]]
- [ ] ![[Raj Shamani]]
- [ ] ![[Personal Dream]]
- [ ] ![[Morning vs Night Person]]
- [ ] ![[Life Hacks]]
- [ ] ![[How to think creatively]]
- [ ] ![[Heart vs Mind ]]
- [ ] ![[Family Treasure]]
---
# Metadata used for sync
id: "92e25350-520a-11ed-b462-093c40a95716"
title: "Persevrance"
source: ""
created_date: "2022-10-22"
modified_date: "2022-10-22"
deleted: true
---
What Is Perseverance in
Psychology?
We can understand perseverance as
a continuous drive to reach our goals
and improve our skills and performance
through persistent effort. It is a form of
purposefulness and goal-orientation,
which requires long-term commitment and
discipline. It is fueled by passion.
Our potential is one thing. What we do with
it is quite another. While aptitude, skills,
and a basic degree of talent are important
as determiners of success, they are not as
significant as hard work and trying, again and
again, to improve what we do. 