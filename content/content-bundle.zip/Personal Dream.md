---
# Metadata used for sync
id: "dc2c90e0-4fb0-11ed-8774-ab88e54243af"
title: "Personal Dream"
source: ""
created_date: "2022-10-19"
modified_date: "2022-10-19"
deleted: true
---
I'll give you a small exercise that
can really motivate you.
Ask your mom what her personal
dream is. Like a big dream.
This dream should not be for you or
her family but just her dream.
Maybe she wants to travel around
the world or maybe she wants a
house who knows. You can never
know a mothers secret.
You may not get the answers
rightaway but once you do just say
ok and start working on making
that dream come true. That will
instantly fire up to get up and start
doing stuff:)
And keep that goal in mind every
time you lose motivation 