---
# Metadata used for sync
id: "f3b62910-54ec-11ed-9681-ef01f6e22e55"
title: "Podcast twitter space"
source: ""
created_date: "2022-10-26"
modified_date: "2022-10-26"
deleted: true
---
Microphones: A good quality mic will help
a lot but, you'd be better spending on acoustics
in a room rather than thousands on a mic..
Sound dampeners/panels make a huge
difference on overall quality and, are really
cheap! Dot them around your space
James Spurin | Dive Into Ansible @ Jan 9
Google the mic pickup patterns and choose for
your environment.
An omnidirectional mic will pickup that dog
barking. police sirens or your kids playing
A cardioid however, is much more targeted to
your speaking area, therefore saving time on
post edit

James Spurin | Dive Into Ansible @ Jan 9
A good budget mic is the Rode Smartlav+, it's
cheap, nice sound and can be used both with
mobile and pc/macs (buy the Sc3 adapter). It's
also great for the likes of zoom calls
James Spurin | Dive Into Ansible@ Jan 9
If you're going to spend out on an expensive mic,
do your research on Dynamic vs Condenser
rather than just choosing the Amazon
bestselle... (like I did once)
Very different sound use cases/quality and
depending on your type of content, one might
suit better than another
James Spurin | Dive Into Ansible @ Jan 9
Graphical Content: Photoshop/Gimp or other
traditional packages are the typical go to but...
Vector based software (like illustrator) for
content where you are generally using or
manipulating elements is highly effective, I
cannot recommend this enough
James Spurin | Dive Into Ansible @ Jan 9
Vector graphics have infinite resolution allowing
you to manipulate and reuse the content whilst
maintaining a very high standard of content
quality



You also get brilliant re-use. That huge diagram
you make one day can easily be a thumbnail the
next day
James Spurin | Dive Into Ansible @ Jan 9
Screen Capture: There's lots of software for
this, you always want to check FPS and output
formatsS.
Many use OBS but personally, I love Screenium
(Mac based).
It supports 60FPS and can output in Pro Res.
You also have mouse visible/hidden as an export
option
James Spurin | Dive Into Ansible Jan 9
When screen recording content, I recommend
setting a 16:9 aspect ration (like 1080p). If you
have a Retina display (Mac) a 1080p HiDPl can
be captured in 4K (with the 1080p sizing), super
crisp quality (but longer upload/yt optimisation
times!)


James Spurin | Dive Into Ansible@ Jan 9
It's important to remember that many will watch
your content on a mobile phone, so, if you're in
the terminal, remember to yank the size of the
font up before recording or, be prepared to edit
and zoom (watch out... you need resolution to
zoom in without quality loss)
James Spurin | Dive Into Ansible Jan 9
Presentations: We've all experienced death
by PowerPoint at some time, but, it really
doesn't need to be like this. Both PowerPoint
and Keynote can be amazing tools that really
make a difference to your content
James Spurin | Dive Into Ansible@ Jan 9
Spend time Googling 'advanced
PowerPoint/Keynote animation and presenting
for use in your content
An example, search for Parallax Transition Effect
with either of the two. You may be surprised at
how awesome this can be and that your canvas,
isn't confined to a rectangle!




James Spurin | Dive Into Ansible @ Jan 9
An overlooked feature I love on both of these is
the ability to export directly as a high quality
movie. Rather than screen capturing yourself
showing a slide deck, use a high qualityy
rendering direct in your content!
James Spurin | Dive Into Ansible@ Jan 9
Look and Feel: There's some techniques you
can do to keep the viewers attention during your
content and once you know about them, you'll
see them everywhere!
For example, Google 'Ken Burns Effect... use
James Spurin | Dive Into Ansible @ Jan 9
Whilst this is a YT video about James Bond, it
gives some great insights into techniques that
you can borrow for your own content
youtube.com
How Cinematography In
Casino Royale' Revolutionize..
James Spurin | Dive Into Ansible @ Jan 9
Punch and Roll: If you're recording audio
and you make a mistake, or... need to make an
update to existing content, it's definitely worth
looking into Punch and Roll.



It's a convenient way of changing a segment of
whilst staying consistent with the content before
and after
James Spurin | Dive Into Ansible@ Jan 9
Finally, one of my favourite goto channels on YT
if you are going to commit to expensive items for
content (lighting, audio, streaming devices,
cameras etc) is DSLR Video Shooter
It's a goldmine of information and he's done this
for years!