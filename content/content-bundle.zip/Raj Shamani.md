---
# Metadata used for sync
id: "8fe2e460-4956-11ed-aabf-9f25594c6eb6"
title: "Raj Shamani"
source: ""
created_date: "2022-10-11"
modified_date: "2022-10-11"
---
rajshamani Instead of feeling bad every night about wasting
your day, ask yourself what did you do wrong today. It
could be anything, but be transparent and honest with
yourself.