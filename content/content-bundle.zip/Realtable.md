---
# Metadata used for sync
id: "effb37a0-5462-11ed-8fa0-5934aad61c1c"
title: "Realtable"
source: ""
created_date: "2022-10-25"
modified_date: "2022-10-25"
deleted: true
---
"The person who says he knows what he thinks
but cannot express it usually does not know what
he thinks."
MORTIMER ADLER
We learn from books, but also from people
we talk to, and the various positions, ideas,
and opinions we are exposed to. We have
to know how to sort through the relevant
information and discard what is not worth
learning. 