---
# Metadata used for sync
id: "38349480-5445-11ed-a3c3-3525bc6fd230"
title: "Rule of One Thing"
source: ""
created_date: "2022-10-25"
modified_date: "2022-10-25"
deleted: true
---
rajshamani What's that one rule you follow in your life?
Since the start, my family has taught me to follow the rule
of one thing, and it has helped me become productive and
is my productivity hack.
Every morning wake up and decide to do only one task in
one day, once you finish that task, then only focus on
something else.
It may look like 'oh! I am only doing one thing today, I should
do more, but doing just one thing at a time will help you to
get more done over a long period of time. 