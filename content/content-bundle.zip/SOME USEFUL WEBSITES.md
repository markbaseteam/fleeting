---
# Metadata used for sync
id: "df7ddc10-730d-11ed-a10e-f5afb13fb3e7"
title: ""
# Extracts all tags in content into the metadata
tags: []
source: ""
created_date: "2022-12-03"
modified_date: "2022-12-03"
deleted: true
---
😍SOME USEFUL WEBSITES😍

1. Screenr.com: This website helps you Record movies on your computer  and send them      straight to YouTube.


2. Bounceapp.com:  For capturing full length screenshots of  a web pages.


3.Goo.gl : Shorten long URLs and convert URLs into QR codes.


4. untiny.me: Find the original URLs that's hiding behind a short URLs. 


5. localti.me: Know more than just the local time of a city


6.copypastecharacter.com: Copy-paste special characters that are not on your keyboard.


7. topsy.com :A better search engine for twitter.


8. fb.me/AppStore -Search iOS apps without launching iTunes.


9. iconfinder.com -The best place to find icons of all sizes.


10. office.com -Download templates, clipart and images for your Office documents.


11. woorank.com -everything you wanted to know about a website.

11.@Myhackersworld -get everything related to hacking for free

12. virustotal.com -Scan any suspicious file or email attachment for viruses.


13. wolframalpha.com - Gets answers directly without searching .

14.printwhatyoulike.com - Print web pages without the clutter.


15. joliprint.com -Reformats news articles and blog content as a newspaper.


16. isnsfw.com- When you wish to share a NSFW page but with a warning.


17. eggtimer.com - A simple online timer for your daily needs.


18. coralcdn.org -If a site is down due to heavy traffic, try accessing it through coral CDN.


19. random.org- Pick random numbers, flip coins, and more.


20. mywot.com -Check the trust level of any website .


21. viewer.zoho.com -Preview PDFs and Presentations directly in the browser.


22. tubemogul.com -Simultaneously upload videos to YouTube and other video sites.


23. truveo.com- The best place for searching web videos.


24. scr.im - Share your email address online without worrying about spam.


25. spypig.com - Now get read receipts for your email.


26. sizeasy.com -Visualize and compare the size of any product.