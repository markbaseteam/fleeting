---
# Metadata used for sync
id: "c8468000-550e-11ed-93d2-3717ccf7eec3"
title: "Sample Mail"
source: ""
created_date: "2022-10-26"
modified_date: "2022-10-26"
deleted: true
---
Here's a quick mail
template to reach out to
super busy people.
Hi, I know your time is valuable so I'll
keep this short.
My name is Varun and I'm a 21 year old from
Bangalore.
Your work at XYZ is really inspiring.
I saw that you guys are hiring on Linkedin
I was wondering if you'd be open to a 5 minute call to
discuss what skills I can develop and if I can shadow
you for a few days or get an internships
I'm pretty sure you would have written a similar mail
to someone when you were starting your company :)
Please do let me know if you'd be available for a quick
call.
Thank you.
P.S: there's no downside in this for you. Because
you'll meet someone who's really curious and
ambitious and if mentored could add a lot of value to
your company in the future. 