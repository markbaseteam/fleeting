---
# Metadata used for sync
id: "a5a221e0-59cc-11ed-8892-93a2fe8b9394"
title: ""
source: "https://www.google.com/search?q=theshinkasen+effect&oq=theshinkasen+effect&aqs=chrome..69i57.7675j0j4&sourceid=chrome-mobile&ie=UTF-8"
created_date: "2022-11-01"
modified_date: "2022-11-01"
deleted: true
---
Shunkasen