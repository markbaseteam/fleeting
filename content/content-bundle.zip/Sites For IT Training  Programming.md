---
# Metadata used for sync
id: "1817ea30-7303-11ed-868a-9724eabee8f6"
title: ""
# Extracts all tags in content into the metadata
tags: []
source: ""
created_date: "2022-12-03"
modified_date: "2022-12-03"
deleted: true
---
Sites For IT Training  Programming, Web Development, Networking and More

 

*********
1. www.codecademy.com 
2. www.lynda.com 
3. www.udemy.com 
4. www.udacity.com 
5. www.coursera.org 
6. www.w3schools.com 
7. www.thenewboston.org 
8. www.programmr.com 
9. www.codeavengers.com 
10. www.codeschool.com 
11. www.learnstreet.com 
12. www.teamtreehouse.com 
13. www.sqlzoo.net 
14. www.codehs.com 
15. www.teamtreehouse.com 
16. www.html5rocks.com 
17. www.codepen.io 
18. www.sitepoint.com 
19. www.tutorialspoint.com 
20. www.javatpoint.com 
21. www.cplusplus.com 
22. www.learncpp.com 
23. www.tutorialspoint.com 
24. www.cprogramming.com 
25. www.stackoverflow.com 
26. www.learncodethehardway.org 
27. www.bloc.io 
28. www.howtocode.io 
29. www.edx.org 
30. www.instructables.com 
31. www.developer.apple.com 
32. www.developer.android.com 
33. www.developers.google.com 
34. www.developer.mozilla.org 
35. www.msdn.microsoft.com 
36. www.dev.opera.com 
37. www.www.developphp.com 
38. www.quackit.com 
39. www.htmlite.com 
40. www.siteduzero.com 
41. www.dreamincode.net 
42. www.phpbuddy.com 
43. www.php.net 
44. www.microsoftvirtualacademy.com 
45. www.professormesser.com .

*Photoshop and Graphics*

1. www.adobe.com 
2. www.adobeknowhow.com 
3. www.pixel2life.com 
4. www.photoshopessentials.com 
5. www.photoshop-tutorials.deviantart.com 
6. www.phlearn.com 
7. www.design.tutsplus.com 
8. www.practicalphotoshopmag.com 
9. www.tutorial9.net 
10. www.pshero.com 
11. www.psdlearning.com 
12. www.alison.com 

*Programing and Other IT Projects*
***********
1. www.freeprojectscode.com 
2. www.sourcecodesworld.com
3. www.freecode.com 
4. www.codeproject.com 
5. www.freestudentprojects.com 
6. www.programmersheaven.com 
7. www.code.google.com
 8. www.planet-source-code.com 
9. www.dzone.com 
10. www.thefreecountry.com 
11. www.sourceforge.net 
12. www.creately.com/diagram-examples 
13. www.freewebsite.com

*Photoshop and Graphics*
*
1. www.adobe.com
2. www.adobeknowhow.com
3. www.pixel2life.com
4. www.photoshopessentials.co
5. www.photoshop-tutorials.deviantart.com
6. www.phlearn.com
7. www.design.tutsplus.com
8. www.practicalphotoshopmag.com
9. www.tutorial9.net
10. www.pshero.com
11. www.psdlearning.com
12. www.alison.com

*Programing and Other IT Projects*
***********
1. www.freeprojectscode.com
2. www.sourcecodesworld.com
3. www.freecode.com
4. www.codeproject.com
5. www.freestudentprojects.com
6. www.programmersheaven.com
7. www.code.google.com
8. www.planet-source-code.com
9. www.dzone.com
10. www.thefreecountry.com
11. www.sourceforge.net
12. www.creately.com/diagram-examples
13. www.freewebsitetemplates.com
14. www.templatemo.com
15. www.oswd.org
16. www.designrazzi.net/2014/free-css3-html5- templates
17. www.html5up.net
18. www.freehtml5templates.com
19. www.themesbase.com/WordPress-Templates
20. www.templaty.com
21. www.arblogger-templates.com
22. www.templates.ssdaa.com

*Create a Prefessional CV Online*
********
1. www.khamsat.com
2. www.fiverr.com
3. www.odesk.com
4. www.elance.com
5. www.99designs.com
6. www.freelancer.com
7. www.guru.com
8. www.jobs.smashingmagazine.com
9. www.freelanced.com
10. www.ifreelance.com
11. www.peopleperhour.com
12 www.peopleperhour.com

*Very Good Sites for Freelancers*
*******

1. www.khamsat.com
2. www.fiverr.com
3. www.odesk.com
4. www.elance.com
5. www.99designs.com
6. www.freelancer.com
7. www.guru.com
8. www.jobs.smashingmagazine.com
9. www.freelanced.com
10. www.ifreelance.com
11. www.peopleperhour.com
12 www.peopleperhour.com

Share and Support US..🔥❤️

Posted by :- @Shuboy_18