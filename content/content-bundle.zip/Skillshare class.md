---
# Metadata used for sync
id: "86265e20-520c-11ed-a927-993c1d01eee0"
title: "Skillshare class"
source: ""
created_date: "2022-10-22"
modified_date: "2022-10-22"
deleted: true
---
For our class project, simply follow the steps
covered in this course to createa product video.
First, I would like you to choose any product that
seems fun. It can be an actual product you plan
to market or a completely imaginary product.
All the images you'll need can be found within
Canva and, of course, feel free to upload your
Own if you prefer.
Use your product idea to createa video that
meets the following criteria:
5-15 seconds
One or more images of the product
Text of your product's name
Text of the benefits and features of your product
Animation of image and/or text
Have fun and be creative 