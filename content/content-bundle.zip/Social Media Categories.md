---
# Metadata used for sync
id: "eb1a3fb0-520a-11ed-8e1f-a15cf67caefa"
title: "Social Media Categories"
source: ""
created_date: "2022-10-22"
modified_date: "2022-10-22"
deleted: true
---
Design
Wallpapers
Posters/prints
Emojis/bitmojis
Fonts
Photoshop/illustrator templates
Branding services
Photoshop services (airbrushing, touch-ups, etc.)
Logo design
Business card design
Infographic design
Turn images into vector files
Powerpoint / Keynote presentation templates
Printout origami
Printable ocoloring book pages
3D models
VR/AR templates
3D printer design files
lcon sets
Animations
Wedding invitation templates
CGI models
Comics
Printable calendars
Printable journals




Information
products
Language lessons
Financial consultations
Financial planning
Coaching/mentoring sessions
Tutoring
Resume touchups
Essay-writing services
Translations
Social media marketing
User testing
Proofreading
Editing
Audits (accounting audits, content audits, etc.)
Career consultations




Other
Courses - of any and all kinds
Sewing patterns
Knitting patterns
Architectural plans
Nutrition plans
Meal-prep plans
Workout plans
Custom vacation/travel planning
Virtual assisting
Worksheets (educational curriculum ideas)
Paid newsletters
Woodworking instructions - step-by-step tutorials
Custom beauty/style/skincare consultations
Drawing lessons - step-by-step
Boardgame printouts
Astrology readings
Car/equipment repair manuals
Meditation/sublim inal programs
Stock market analysis software
Minecraft skins/renders
Painting tutorials