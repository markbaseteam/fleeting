---
# Metadata used for sync
id: "1169b550-72b9-11ed-81fa-57e94c379746"
title: ""
# Extracts all tags in content into the metadata
tags: []
source: ""
created_date: "2022-12-03"
modified_date: "2022-12-03"
deleted: true
---
Something that can help you.
At any point of your life if you can have these 3 tangible goals running parallelly then it can lead to a more fulfilling life
Physical Goal - career, money, house, cars, wealth etc
Emotional Goal - love, sacrifice, giving back to society etc
Spiritual Goal : self-awareness, empathy, compassion etc
These 3 when merged together is like a gourmet meal for the soul :)