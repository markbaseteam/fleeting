---
# Metadata used for sync
id: "253cda30-495b-11ed-81f9-f9b4ee2b0b98"
title: "Story of your life idea"
source: ""
created_date: "2022-10-11"
modified_date: "2022-10-11"
deleted: true
---
Has anyone seen/created a
choose-your-own-path novel in obsidian
using [links]?
The idea came to me when I was checking out the LYT 6
LVault, and the 'start here' note had the line, "You take a
breath and enter the forest" followed by a link.
I see a ton of potential in creating a
choose-your-own-adenture-story.
ex: long chunk of narrative blah blah blah blah* [turn
left]] [[turn right|]
The story would then fork, and you would continue
reading the version where the choice you made
happened. I'm sure someone has thought of this idea
before, and I know these kinds of stories exist already,
but I was wondering if anyone had created one in
obsidian. I feel like it would be cool to see the graph
view afterward - to see all the possible paths vs. the one
you chose. After you finish, you could even go back to a
precise point in the story and choose a different option.
Could this idea be taken further?

CYOA GAME