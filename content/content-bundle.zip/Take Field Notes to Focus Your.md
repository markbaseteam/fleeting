---
# Metadata used for sync
id: "b6655f60-60d9-11ed-9a81-192f8f8bb4bf"
title: ""
source: ""
created_date: "2022-11-10"
modified_date: "2022-11-10"
deleted: true
---
Take Field Notes to Focus Your
Attentions
If you're really struggling to pay attention
and personal challenges aren't working,
try field notes: writing descriptions and
drawing pictures of what you see.
If you're at work, dedicate 10 minutes to
observing one person's behavior. Jot it down o
paper.
This will help you to start paying attention
to the tiny details.