---
# Metadata used for sync
id: "c4d699c0-5462-11ed-a48d-19672bbde69c"
title: "Taking action hard"
source: ""
created_date: "2022-10-25"
modified_date: "2022-10-25"
deleted: true
---
Confidence
Motivation and expectation of success create a
feedback loop:
Your motivation to complete a task
depends on the value of the reward and
your expectation of success.
Your expectation of success depends on
your motivation.
If your projects tend to fail, your expectations
are low, and motivation fades. If your projects
tend to succeed, your expectations go up,
and motivation stays strong. 