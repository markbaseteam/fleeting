---
# Metadata used for sync
id: "68859950-520a-11ed-ae97-8777009dc8c6"
title: "The Growth Paradox"
source: ""
created_date: "2022-10-22"
modified_date: "2022-10-22"
deleted: true
---
The Growth Paradox
They tell you to travel when you're
young, but you're always short of
cash
They ask you to experiment, but no
company will take you in without any
experience
They tell you that must read but you
get absolutely no time
They tell you to network but you hate
meeting people 