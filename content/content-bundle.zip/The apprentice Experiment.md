---
# Metadata used for sync
id: "6b6fb820-5021-11ed-8a11-2df2044b5534"
title: "The apprentice Experiment"
source: ""
created_date: "2022-10-20"
modified_date: "2022-10-20"
deleted: true
---
The Apprentice Experiment
Every weekend pick a professional from a different
field and become their apprentice for just 2 days.A
chef, filmmaker, tech startup founder, designer,
YouTube creator, author etc. Do this for 12
weekends and at the end of it you'll know which
weekend made you the happiest. That's the start
to find your calling : 