---
# Metadata used for sync
id: "8ede7b00-5870-11ed-b30c-0dc245a1168a"
title: ""
source: ""
created_date: "2022-10-31"
modified_date: "2022-10-31"
deleted: true
---
The cost of athing is
the amount of your life
which will be given in
exchange for it,
immediately orin the
long run.


Don't give up what your want MOST for
what you want NOW


Pro tip: If you don't know
what to do in life, start with
the thing you are most
obsessed with.