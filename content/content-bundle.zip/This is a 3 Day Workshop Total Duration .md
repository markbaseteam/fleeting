---
# Metadata used for sync
id: "d0a34f30-6e86-11ed-b4f2-0b6edb9025a8"
title: ""
# Extracts all tags in content into the metadata
tags: []
source: ""
created_date: "2022-11-28"
modified_date: "2022-11-28"
deleted: true
---
This is a 3 Day Workshop
Total Duration - 9 Hours
This is what you will learn :
- How to register your business
- How to get a GST number for your business
- How to setup your website domain
- How to start designing your website
- How to setup the backend systems
- Mobile optimisation of your website
- How to start your e-commerce store for under 1500 rupees
- How to setup your website hosting for under 1500 rupees
- How to integrate your website with Google analytics
- How to setup Facebook Pixel with your store
- How to setup automated email systems
- How to setup a payment gateway
- How to integrate your bank account with your payment gateway
- How to integrate your payment gateway with your website
- How to take your product images yourself without spending anything
• How to create a marketing plan for your store
- Enabling and Automating Shipping
- Privacy Policy and Refunds
- How to automate everything
- Basics of marketing your E-Commerce Store