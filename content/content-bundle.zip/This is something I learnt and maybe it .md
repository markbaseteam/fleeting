---
# Metadata used for sync
id: "2146fec0-6e85-11ed-b4f2-0b6edb9025a8"
title: ""
source: ""
created_date: "2022-11-28"
modified_date: "2022-11-28"
deleted: true
---
This is something I learnt and maybe it can help you :
The loss of someone we know and the resultant grief can put us in touch with our own mortality. If that person can die unex-pectedly, then so can I. What does this mean for me and my life? What meaning does today have?
You could probably feel the same way if you've had a tough breakup. I read this somewhere - One of the reasons why breakups really suck is because not only your present falls apart but also the future associated with it. And having the future taken away is the scariest
But losing someone doesn't mean giving up on life. It's actually quite the opposite. It bring a stronger sense of things we want, adventures we want to pursue and the people we want to be with.
It takes time but I promise you this realisation will eventually happen. Hang in there. I know that feeling and it's ok. It will pass :)
