---
# Metadata used for sync
id: "2204fdb0-5451-11ed-924d-195bac68edbe"
title: "Tricks to do"
source: ""
created_date: "2022-10-25"
modified_date: "2022-10-26"
deleted: true
---
5. If you need to deescalate
someone and get them to
communicate, ask them
questions about numbers or
personal information.

4. When you have something
important to say to your kids,
say it very quietly so that they
listen. They're immune to your
yelling, but whispering gets
their attention.


3. Instead of asking,
'Do you have any questions?
ask, 'What questions do you have?
The first almost always results in
silence, while the second helps
people feel comfortable asking
questions.

Next time you feel sad (again) then put
your hands into ice water and start to think
about the positive things that had happened
in your life. You will feel relaxed and this
trick will also cure your headache.


"I want to be rich" means
h) you wat to get rid of the alarm
clock
2) you want to leisurely spend time
with people you love
3) you want to stop worrying about
the rent or whether you can buy
healthy food
4) you want to be able to help
5) you want to do more of what you
love