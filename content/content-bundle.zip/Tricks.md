---
# Metadata used for sync
id: "15c28340-6c86-11ed-96ba-353e1b31f947"
title: "Tricks"
source: ""
created_date: "2022-11-25"
modified_date: "2022-11-28"
deleted: true
---
Trick: Get someone to do a favor for you-also known as the Benjamin Franklin effect.

Legend has it that Benjamin Franklin once wanted to win over a man who didn't like him. He asked the man to lend him a rare book and when the book was received he thanked him graciously. As a result, this the man who had never wanted to speak to him before, became good friends with Franklin. To quote Franklin: "He that has once done you a kindness will be more ready to do you another than he whom you yourself have obliged."

Scientists decided to test this theory and found that those who were asked by the researcher for a personal favor rated the researcher much more favorably than the other groups did. It may seem counter-intuitive, but the theory is pretty sound. If someone does a favor for you, they are likely to rationalize that you must have been worth doing the favor for, and decide that therefore they must like you.





Trick: Ask for way more than you want at first then scale it back later.

This trick is sometimes known as the door in the face approach. You start by throwing a really ridiculous request at someone-a request they will most likely reject. You then come back shortly thereafter and ask for something much less ridiculous-the thing you actually wanted in the first place. This trick may also sound counter-intuitive, but the idea behind it is that the person will feel bad for refusing your first request, even though it was unreasonable, so when you ask for something reasonable they will feel obliged to help out this time.

Scientists tested this principle and found that it worked extremely well as long as the same person asked for both. bigger and smaller favor, because the person feels obliged to help you the second time and not anyone else.