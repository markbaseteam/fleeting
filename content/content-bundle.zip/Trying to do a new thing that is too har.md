---
# Metadata used for sync
id: "32a092e0-60d8-11ed-9d60-bf435be3aa22"
title: ""
source: ""
created_date: "2022-11-10"
modified_date: "2022-11-10"
deleted: true
---
Trying to do a new thing that is too hard?
Learn for 10 days,
then practice for the next 10 days,
then teach for the next 10 days.
That's it, that's the secret of going from hard mode
to easy mode in 30 days.