---
# Metadata used for sync
id: "c27b65b0-60d9-11ed-9f25-6f02a0514028"
title: ""
source: ""
created_date: "2022-11-10"
modified_date: "2022-11-10"
deleted: true
---
Unpopular opinion: young adults
should not be living with their
parents or at least live outside for a
few years. There's immense value in
learning how to do the dishes, wash
your clothes and be responsible for
yourself.