---
# Metadata used for sync
id: "3815f940-60d8-11ed-9d60-bf435be3aa22"
title: ""
source: ""
created_date: "2022-11-10"
modified_date: "2022-11-10"
deleted: true
---
Unsuccessful people
make dicision based
on their current
situations. Succesful
people make
decisions based on
where they want toO
be."

A little existential crisis, insecurity and indecisiveness floating in a confusion gravy.

If you can't see your way through, but can see your next step, then just take
that.


The funny thing about grief is
that it would disappear for
weeks together and then
randomnly show up unannounced
and leave you numb


Did you know the original quote (attributed to William Shakespeare) is always
shortened to make it seem like a negative thing, when actually it's "A Jack of all
trades is a master of none, but still always better than a master of one" - yes, it's
more than ok to try many things! It's a benefit if you've had more than one career,
or follow more than one passion, or paint in more that one style., Don't limit
yourself if you don't want to! Of course be discerning about what you Spend your
energy focusing on.. but if you love multitude of creative pursuits and disciplines -
lean into that!


