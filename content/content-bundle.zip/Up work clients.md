---
# Metadata used for sync
id: "45f9d700-520c-11ed-b77a-65e2ebc2cbf8"
title: "Up work clients"
source: ""
created_date: "2022-10-22"
modified_date: "2022-10-22"
deleted: true
---
2. Payment un verified pay proposal send
kr saktay hain. If client Upwork pay new
ho to. Like 3, 4 din pehlay profile banaai
ho uss ne.
3. Proposal send krtay waqt client k naam
say baat start krain. Or client key country
k time k hasaab say usko good evening
yaa good afternoon b bolay. Zayada
achaa impression parday gaa.
4. At least 60% hire rate walay client ko
proposal send krain. Reviews b dekhay. K
past main jin freelancers ne iss client k
saath kaam kiya hay wo kaya opinion
rakhtay iss client k related.
5. Specialized profile banaay. Or jo
specialized profile proposal key
requirements k hasaab say fit ho, oos
specialized profile say proposal send
krain.
6. Hello shello k baad direct client key
problem, jo client ne proposal main likhaa
hay usko discuss krain. Phir client ko
bataay apka uska problem kesay solve
kro gee or Apko he Q select kray client.
Phir end pay apne or apni expertise k
baaray main bataay.
7. Ek call to action k saath proposal ko
khatam krain or Q k ap new ho to client ko
attract krne k liye thora discount b offer
krain.
8. Client ko bataay k you are ready to
work. 