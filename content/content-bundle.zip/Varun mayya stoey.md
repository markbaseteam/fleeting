---
# Metadata used for sync
id: "696f9e40-5446-11ed-90ec-33679a6d3719"
title: "Varun mayya stoey"
source: ""
created_date: "2022-10-25"
modified_date: "2022-10-25"
deleted: true
---
With exceptions of abnormally functioning bodies
or overeating, your disgestive system is largely
ready to go all the time. Digestion is one of the
major functions of keeping you alive, so your
body is fine with stuffing calories into it whenever
it can. You can eat any time, you probably
shouldn't eat all the time.
As for the second one, I don't think you actually
can choose when you go to the bathroom the way
you say. Generally you have to go when your body
tells you to go, but you really only have the option
of going right then or using trained muscle
functions to restrict your body from going right at
that moment. It's something you spend years
working on as a child to the point that you don't
even notice anymore. Like people who learn
circular breathing or breathing with the
diaphragm from a young age.
The comparison to "sleeping on command" is like
saying you can pee at any time you want
regardless of whether you have urine in your
bladder or not. In reality the decision to go to the
bathroom is more Ilike being very sleepy and just
choosing to stay awake instead and put off sleep
for a little longer. 