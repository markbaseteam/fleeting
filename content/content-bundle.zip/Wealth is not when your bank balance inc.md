---
# Metadata used for sync
id: "bd598340-6f8f-11ed-a3ee-e9fa0d462aff"
title: ""
# Extracts all tags in content into the metadata
tags: []
source: ""
created_date: "2022-11-29"
modified_date: "2022-11-30"
deleted: true
---
Wealth is not when your bank balance increases but when all things become affordable to YOU


You can literally write the first page of a fiction story in the notes app on your phone and post that on Instagram with 12 follower
Fuck excuses . people are loaded with things like "I don't have a team" "I don't have the right camera" "I don't have this" "this isn't" "if only" .. excuses just expose fear and insecurities..