---
# Metadata used for sync
id: "1b653c50-6fd5-11ed-a84d-1fef11c365ee"
title: "What to do in Free Time"
# Extracts all tags in content into the metadata
tags: []
source: ""
created_date: "2022-11-29"
modified_date: "2022-11-30"
deleted: true
---
ORIGAMI DATE
calming origami tutorials to follow together and


Paint Together
No, not to channel or challenge each other's inner Picasso but the Majnu bhai. Select an easy to paint photo. Turn up the video call. Paint together while talking.
It's wv fun and therapeutic tbh.
Later you can do an Insta poll to see who did it better!

Watch Stuff
Together
First base is watching a movie/ starting a TV show together (on teleparty)
Second base is laughing at standup shows together (discord)
Third base is watching bachpan ke puraane cartoons together.

Code Names
It's a team vs team game and each team needs to guess some words based on the clues given by spy-master. Discord introduced me to this, although I was clueless & lost in its first round, my detective skills have now scaled new heights, just name the clue and I'll hit it.

Name Place Animal Thing Online. Yes It Exists.
Straight out of your copy ka last page in school, it's available online too and is still that much fun. Wahi same rules but new kind of experience. Also, no one can peek in each other's notebooks now and if you still take google's help, then itne saalo ki mehnat ka kya fayeda?

Listen To Music Or
Audiobook Together
Join discord. Create a server. Add a music bot. Hit play on a playlist or take turns playing songs, and vibe together while talking. Or play an audiobook that you both can listen to together and discuss after every chapter!
@

Gartic Phone
If you & your friends have been done & trough with Skribble, then you can try Gartic Phone, where instead of just words you can give each other full blown sentences while the others would have to guess it and then just obv laugh at your majnu bhai inspired drawing skillzzz!!

