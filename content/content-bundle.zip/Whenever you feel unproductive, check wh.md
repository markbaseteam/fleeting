---
# Metadata used for sync
id: "7195d1f0-5434-11ed-8fbb-8b967eb4b61a"
title: ""
source: ""
created_date: "2022-10-25"
modified_date: "2022-10-25"
deleted: true
---
Whenever you feel unproductive, check whose standards are you worried about?

1. THE GOAL

Measure your productivity not by goals defined by others, but by yourself.

Person1 : aim for the stars
Person2 : no tq, I am happy with moon


2. THE PACE

Someone's having kids at 30, someone's completing education. 
You have decades of adult life.
Live at your own pace.

Person1 : I will have kids by 30.
Person2 : I will kick their Butts at FIFA

3. THE PATH
some people like staright growth.
Some like pitstops. Choose what you likem