---
# Metadata used for sync
id: "b3fc9630-67ff-11ed-a45a-fdf258645066"
title: ""
source: ""
created_date: "2022-11-19"
modified_date: "2022-11-24"
deleted: true
---
Write a blog on 5 or 9 new things you learned about topics
Twitter thread explaining 10 new words from vocabulary 
LinkedIn post reviewing course instructors pace content exercises etc


