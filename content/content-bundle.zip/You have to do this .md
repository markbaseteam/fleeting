---
# Metadata used for sync
id: "04773f20-51f3-11ed-b11a-9bb04601853e"
title: "You have to do this "
source: ""
created_date: "2022-10-22"
modified_date: "2022-10-22"
deleted: true
---
1. Think of a topic that is natural to
you not something you think will
make you look smart
2. Make a script around that
3. Practice practice practice