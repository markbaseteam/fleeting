---
# Metadata used for sync
id: "37f9efc0-5435-11ed-a0ef-13cb3bce56f0"
title: "alter ego game"
source: ""
created_date: "2022-10-25"
modified_date: "2022-10-25"
deleted: true
---
Your defense mechanism is...
"Cover up the undesirable."
Denial
You're the type to turn away from anything
that may breed anxiety or pain.
Like a stubborn child, you close your eyes to
anything you dislike. Why not try facing
your problems every once in a while, instead
of shunning them?
You also seem to be good at idealizing and
idolizing others. Only an idealist like you
would be so haunted by presumed betrayal. 