---
# Metadata used for sync
id: "b04f41a0-60d8-11ed-9d60-bf435be3aa22"
title: "artis"
source: ""
created_date: "2022-11-10"
modified_date: "2022-11-10"
deleted: true
---
You are a amazing artist
How to make gotden or stiver
cofor in ibis paint x tool??
please guide
1. Select a brush of your Choice
pencit, pen, coarse pencit ete)
2.Duplicate the brush by adding
it to custom brushes
3. Go to the setting of that
brush and set the blending mode
to " Add"
4. Fill a layer wi th dark cofor of
your choice (it wilt be our
background layer)
5. Add another layer above that
background fayer and set the
blending mode to "Add"
6. Choose a broun co lor ( not too
dark not too light) from the
color uheel
And Start uriting wi th that brush


Where do you get
jinspiration from?
lam very inspired by Disney/Pixar Movies,.
beautiful Art Books like The Art of Luca
and others beautiful Disney Art Books,
educational art books and of course by the
work of my fav colleguaes artists