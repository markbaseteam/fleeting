---
# Metadata used for sync
id: "d78c2770-626c-11ed-adce-3f4d4d3a0ca5"
title: "book highi"
source: ""
created_date: "2022-11-12"
modified_date: "2022-11-17"
deleted: true
---
Overall: For big-picture summations of the book; I write
& edit this as I read
Figures: Individuals the books are citing or discussing,
most of my notetaking is here.
Settings: Specific areas, towns, tribes, eras, etc. the
book focuses on


I take notes through a philosophical framework,
questioning the information provided in the book,
reflecting on why something is true in some contexts,
why it's not true in other contexts, what wisdom I can
glean from the information, how I can assimilate it to
use for myself, and most importantly the methodological
underpinnings, history and epistemological framework of
the author of the book.
Pragmatically speaking, this manifests firstly as
explication of an intention as to why I would want to read
a book in the first place, delineating my intentions and
building hypotheses as to what I assume the answers the
books will give me to the questions I have.
Furthermore, I seek to have those hypotheses
disconfirmed, or rarely confirmed, and my mind
challenged by the author,