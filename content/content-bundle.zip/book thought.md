---
# Metadata used for sync
id: "51e8bb00-5435-11ed-bf28-937b6c883fbb"
title: "book thought"
source: ""
created_date: "2022-10-25"
modified_date: "2022-10-25"
deleted: true
---
The biggest mistake we make is that we build our homes in
other people. We build those homes and we decorate them
with the love and care and respect that makes us feel safe at the
end of the day. We invest in other people, and we evaluate our
self-worth based on how much those homes welcome us. But
what many don't realize is that when you build your home in
other people, you give them the power to make you homeless.
When those people walk avway, those homes walk away with
them, and all of a sudden, we feel empty because everything
that we had within us, we put into them. We trusted someone
else with pieces of us. The emptiness we feel doesn't mean we
have nothing to give, or that we have nothing within us. It's
just that we built our home in the wrong place.

Najwa zebian