---
# Metadata used for sync
id: "19b78e90-5445-11ed-b6bc-d9b95ba29bb8"
title: "books check"
source: ""
created_date: "2022-10-25"
modified_date: "2022-10-25"
deleted: true
---
JUST READ BOOKS YOU ENJOY

There's a quote that I love that goes: "Read
what you love until you love to read," and I
think that's so perfect.
If you're reading out of some sense of
misplaced obligation or duty, you' re going
to get discouraged, and you're going to
have a hard time reading 100 books a year 