---
# Metadata used for sync
id: "8c4fd9a0-5209-11ed-b623-a3f5f4574eb9"
title: "business experience"
source: ""
created_date: "2022-10-22"
modified_date: "2022-10-22"
deleted: true
---
Some business advice
from my experience
I would have the same strategy even if I
had a business of any physical product.
I would sell one type of product with
excellent quality.
One excellent product is enough to
make as much money as you want.


For example:
|Let's say someone is good at
baking and is about to start his
business. Instead of offering bakes,
pastries, donuts, bread, patties,
sandwiches, sweets, etc he should
start with one best item.
He focuses on one item. For
example he makes Bento Cakes.
Just bento cakes. His whole
Instagram feed is about bento
cakes. Since he has one product, he
can fully focus on it's quality and
taste.
Soon he will be known as the Best
Bento Cake Baker in the town. 