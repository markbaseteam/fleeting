---
# Metadata used for sync
id: "532f8250-5205-11ed-854f-add7d8cfbf5b"
title: "car"
source: ""
created_date: "2022-10-22"
modified_date: "2022-10-22"
deleted: true
---
The technical significance of clutch (for those
people who want to know what really happens
inside) is that it is a part that connects engine to
gear. The reason to press clutch while shifting
is that it disconnects the current gear from
the engine while the engine is spinning and
transfers the motion of rotation to next gear.
You can search for Lesics Understanding clutch
video for more info. This comment is only for
those who want to know what happens inside.