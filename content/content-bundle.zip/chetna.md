---
# Metadata used for sync
id: "d19fc780-5372-11ed-be1a-e58610d4569b"
title: "chetna"
source: ""
created_date: "2022-10-24"
modified_date: "2022-10-24"
deleted: true
---
Consciousness or Chetna, in simple
words, is a way of living.
It's a way of living in which you stop
getting suffer from sadness or any
such good or bad emotion.
You are neutral in both the situation
of happiness and sadness.
ashutosh ts "Aatma Jad nahi, Chetan hai" this little
sentence has thousands of answers within itself.