---
# Metadata used for sync
id: "de2841e0-5376-11ed-9856-a7e504e8277e"
title: "choice"
source: ""
created_date: "2022-10-24"
modified_date: "2022-10-24"
deleted: true
---
But choice is difficult because it also
represents sacrifice. Choosing something
inherently means giving up something else
-- something we might want tomorrow, or
next week -- and that won't be available to
us if we don't grab it today. 



Doing the same things over and over again will not lead to improvement.
It leads to stagnation.
Don't try harder. Try differently.