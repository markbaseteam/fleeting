---
# Metadata used for sync
id: "b2f98eb0-5372-11ed-8146-1331be1436ab"
title: "dailt encouragment"
source: ""
created_date: "2022-10-24"
modified_date: "2022-10-24"
deleted: true
---
Daily Encouragement by
Daisaku Ikeda
May 7, 2022
Many things happen in life.
There are joyous days and
times of suf fering.
Sometimes unpleasant things
occur. But that ' s what makes
life so interesting . The
dramas we encounter are part
and parcel of being human.
If we experienced no change
or drama in our lives, ifE
nothing unexpected ever
happened, we would merely be
like automatons, our lives
unbearably mono tonous and
dull. Therefore, please
develop a strong self so
that you can enactt the drama
of your life with confidence
and poise in the face of
whatever vicissitudes you
may encounter . 