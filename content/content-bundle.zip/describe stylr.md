---
# Metadata used for sync
id: "76eb1760-6180-11ed-9b1e-fd7f7a43af2a"
title: "describe stylr"
source: ""
created_date: "2022-11-11"
modified_date: "2022-11-11"
deleted: true
---
How would you describe
your style
good question!! probablya
neutral soft girl aesthetic??
hehe if u search "soft girl" on
Pinterest that's pretty close to my
aesthetic but I mostly focus on a
neutral color palette: whites,
browns, blacks, blues, and some
pinks/pastels thrown in there:)