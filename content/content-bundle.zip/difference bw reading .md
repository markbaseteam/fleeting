---
# Metadata used for sync
id: "d804f2d0-5377-11ed-bdb1-efdbcb189758"
title: "difference bw reading "
source: ""
created_date: "2022-10-24"
modified_date: "2022-10-24"
deleted: true
---
The Difference Between
Reading for Understanding
and Reading for Information.
There is a difference between reading for
understanding and reading for information.
AnythIng easlly dlgested is reading for
information. The regurgitation of facts without
A lot of people confuse knowing the name of
something with understanding. While great
for exercising your memory, the regurgitation
of facts without solid understanding and
context gains you little in the real world.
A useful heuristic: Anything easily digested is
reading for information.
Consider the newspaper, are you truly
learning anything new? Do you consider
the writer your superior when it comes to
knowledge of the subject? The odds are
probably not. That means you're reading for
information. It means you're Ilikely to parrot
an opinion that isn't yours as if you had done
the work.