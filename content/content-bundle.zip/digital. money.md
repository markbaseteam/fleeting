---
# Metadata used for sync
id: "cc9334c0-54d5-11ed-afd8-e33df88a34e7"
title: "digital. money"
source: ""
created_date: "2022-10-26"
modified_date: "2022-10-26"
deleted: true
---
1.Earn an immense passive income by having your own
blog
2.Make stock videos and sell on websites
3.An easy method to make passive income by publishing
4.Start creating content on social media through
platforms like Instagram, YouTube etc.
5.Become a virtual assistant
6.Tutor someone by teaching them subjects you're good
7.Sell your personal educational notes online
8.ldentify a skill you're good at and consider freelancing
in a field that matches it
9.Try affliate marketing
10.If you love photography, sell your photos online
11.Sell ítems on online websites like Amazon
12.*Design graphics/ templates and sell them online
13.Become a transcriber or a translator
14.Teach young kids dance, music, sports & so on
15.Participate in online surveys
16.*Assist your peers by helping them with their college
assignments and projects
17.Earn passive income on Pinterest
18.Make a design on T-shirts and earn money online
19.Share educational courses on Udemy to make
passive income
20.As an Indian youngster start to invest money to make
passive income
21.*As an Indian Gen Z earn money by selling affiliate
products
22.Make money through podcasting as an Indian Gen Z
23.Rent out the things which you don't use regularly
24.Sell stock music and make money
25.*Publish your own book to earn royalties
26.Apply the concept of passive saving in your daily life
27.*Apply for government schemes to get monetary benefits
28.Invest money in good business to make passive
income
29.Start your own small business to generate passive
income
30.Sell scripts and earn immense money as a youngster
31Make stock videos and sell on websites 