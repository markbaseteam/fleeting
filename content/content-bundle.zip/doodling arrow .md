---
# Metadata used for sync
id: "f4cdae80-5376-11ed-8445-3d33aa3cbdbf"
title: "doodling arrow "
source: ""
created_date: "2022-10-24"
modified_date: "2022-10-24"
deleted: true
---
This cool test will tell you how healthy your mind
is goo.gl/kBEKJW
ARROWS
AN UPWARDS ARROW MEANS YOU'RE
PEOPLE-ORIENTED; DOWNWARDS -YOU'RE
SELF-FOCUSED; LEFTWARDS-YOU'RE STUCK
IN THE PAST; RIGHTWARDS-YOU LOOK
FORWARD TO THE FUTURE. 