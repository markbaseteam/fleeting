---
# Metadata used for sync
id: "8531f640-5370-11ed-b2c3-79a995ab5708"
title: "dyk"
source: ""
created_date: "2022-10-24"
modified_date: "2022-10-24"
deleted: true
---
- after 14 days without sleep you start
to hallucinate
- 1st born children tend to have a higher
Q than their younger siblings
- emotional pain lasts 10-20 minutes.
anything longer is self inflicted
overthinking
- humor is associated with being smart
and honeest 