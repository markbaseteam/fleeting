---
# Metadata used for sync
id: "b3638ee0-4fb3-11ed-b418-a77944ca49f7"
title: "emotionally over an dunder available"
source: ""
created_date: "2022-10-19"
modified_date: "2022-10-19"
deleted: true
---
Emotionally Over Avaialble:
- My partner is reluctant to get as
emotionally close as I would like.
When I tell my partner my troubles, I feel
like they don't really care.
I find it hard to forgive my partner when
they let me down.
I often worry that my partner doesn't
love me.
I fear that our relationship will end.
Emotionally Unabailable
I prefer to keep to myself when I'm
around my partner.
I don't talk to my partner about my
feelings.
I don't give my partner the chance to let
me down.
I don't want to be around my partner if
I'm feeling upset.
I wouldn't care if my partner leftm


Oh there's one last type:
Someone who's both emotionally
unavailable and also over available
I want to get emotionally close to my
partner, but I worry about them hurting
my feelings.
I want to feel close to my partner, butI
also don't trust them to want to be
close to me.
I can't live without my partner, even
though being with them isn't working
That's it on relationships folks. Thank
you for coming to my Ted Talk.
Have a great weekend :)

For everyone asking for the solution to the
over and under available problem:
-it takes time. Atleasta year to get your
attachement style corrected.
- once you get it corrected you'll reject all
unavailable and overavailable folks so the
pool of people available becomes far
lesser
but you'l find yourself looking for
people with zero drama and someone who
helps you grow as a person
- also real love is actually quite boring.
There's no drama and it's not like Taylor
Swifts Love Story. But it's calm and
soothing
