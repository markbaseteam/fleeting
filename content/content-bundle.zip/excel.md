---
# Metadata used for sync
id: "dd3d0cd0-6e78-11ed-8b4b-ab24cd10496e"
title: "excel"
# Extracts all tags in content into the metadata
tags: []
source: ""
created_date: "2022-11-27"
modified_date: "2022-11-28"
deleted: true
---
1 10 Sites to learn Excel for free
1. Microsoft Excel Help Center
2. Excel Exposure
3. Chandoo
4. Excel Central
5. Contextures
6. Excel Hero b.
7. Mr. Excel
8. Improve Your Excel
9. Excel Easy
10. Excel Jet