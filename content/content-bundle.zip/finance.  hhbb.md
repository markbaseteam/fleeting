---
# Metadata used for sync
id: "5d156200-5451-11ed-871b-5749808e2af5"
title: "finance.  hhbb"
source: ""
created_date: "2022-10-25"
modified_date: "2022-10-25"
deleted: true
---
4. Imagine playing Monopoly
and never buying any assets or
investments that generate incomne.
Imagine you just went around
collecting $200, giving your
money to the rich, and trying
to stay out of jail.
That is how most people live
their lives. 