---
# Metadata used for sync
id: "343981e0-5370-11ed-b2c3-79a995ab5708"
title: "first step of survival"
source: ""
created_date: "2022-10-24"
modified_date: "2022-10-24"
deleted: true
---
Parents kick you out! And you
dont have a job! What will be
your first step to survive

Step 1: Call everyone I know to get
a temporary stay for a night.
Step 2: Go to fiverr.com and list as
many gigs as I can at $5.
Step 3: go to youtube & Learn how
to finish those gigs.
Step 4: keep looking for any/every
job to get initial money.
Step 5: learn every thing about
that job/business to prove my
worth. 