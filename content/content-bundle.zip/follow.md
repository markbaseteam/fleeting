---
# Metadata used for sync
id: "27ac39e0-6180-11ed-9b1e-fd7f7a43af2a"
title: "follow"
source: ""
created_date: "2022-11-11"
modified_date: "2022-11-11"
deleted: true
---
My personal rule which has
helped me the mostin
networking:
don't stand and talk to people
you already know ata party.

Confidence is not the same thing
as Bravery
"Bravery comes from within and cannot
be confused with its egotistical cousin,
confidence"
For this prime example will be Professor
Lockhart and the rest is known to all.

"When we believe we've reached
the zenith of knowledge 
Even an ounce of disappointment can crush us like a ton of bricks. 