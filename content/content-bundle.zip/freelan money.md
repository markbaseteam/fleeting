---
# Metadata used for sync
id: "3d572980-5451-11ed-9523-bdc698a98265"
title: "freelan money"
source: ""
created_date: "2022-10-25"
modified_date: "2022-10-25"
deleted: true
---
Society teaches us to look at money like
this:
40 hours/week for $20/hour = $800
Imagine looking at money money like this:
40 salesx $500 an order $20,000
There's a cap on how many hours you can
work, but there's NO CAP on the number
of sales your business can make. 