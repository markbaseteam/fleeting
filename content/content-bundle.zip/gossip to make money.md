---
# Metadata used for sync
id: "a3abab80-51e9-11ed-aded-ab00b1bb9d78"
title: "gossip to make money"
source: ""
created_date: "2022-10-22"
modified_date: "2022-10-22"
deleted: true
---
How can you use gossip to make
money?
Have you noticed thousands of
Insta creators from whom you learn
everyday? How do they present
their content. The really popular
ones present themselves in a funny
way as different characters talking
to each other. I've seen lots of
finance videos like these.
Well there you go. If you're good at
gossiping convert that ability to
write stories or create content that
can teach people and you can make
really good money :)
Gossip is the most natural form of
storytelling and can be used for a
lot of different things