---
# Metadata used for sync
id: "7fc77000-51e9-11ed-9df4-8b01d16183d5"
title: "grief"
source: ""
created_date: "2022-10-22"
modified_date: "2022-10-22"
deleted: true
---
So how does grief look like a year later ?
It's different for different people but I
have made peace with what happened.
I'm happy now and I look forward to mny
life. There are times when you do get
numb but you will eventually learn how
to get out of it quickly.
The only thing I can say is what worked
for me is to never forget. That feeling or
that moment and memeories both
happy and sad.
Grief is not as bad as Ithought it would
to be
Life always goes on. Life always finds a
way. And the best part - I learnt this
from him:)