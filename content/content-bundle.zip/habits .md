---
# Metadata used for sync
id: "353b5010-60da-11ed-8cf8-2b915e713837"
title: "habits "
source: ""
created_date: "2022-11-10"
modified_date: "2022-11-10"
deleted: true
---
. Floss my teethn
Make the bed
Clean my room or home
Do the dishes
.Take vitamins
. Take medication
Stretch
Do yoga
Go for a run
Lift weights
.Read a book
. Tell someone I love them
.Call a friend or family member
Finish work by 5 p.m.
.Go to sleep by 11 p.m.
Learn something new
.Cook dinner instead of ordering
Random act of kindness
Go outside
.Write in my journal
.Draw or paint
Water my plants
Eat at least five vegetables
Eat at least three fruits


Eat at least three fruits
. Keep an empty email inbox
Have some "me time"
.Pay my bills
Do my bookkeeping
.Do schoolwork or study
And some bad habit tracker ideas to
mark things you successfully avoided:
No smoking
No drinking alcohol
No sugar
No caffeine
.No meat Mondays
No cursing
No screen time after 10 p.m.
.No social media scrolling
No TV