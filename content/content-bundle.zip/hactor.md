---
# Metadata used for sync
id: "15c036a0-6180-11ed-9b1e-fd7f7a43af2a"
title: "hactor"
source: ""
created_date: "2022-11-11"
modified_date: "2022-11-11"
deleted: true
---
Find good projects worth contributing on the
GitHub page. You can type
label:hactoberfest is: issue is:open
.You can add a language label of your
choice to filter open issues. if you are a
beginner and can't find good issues then
there's tag label:good first issue which
filters out issues for beginners who want to
contribute.
Here's something beginner-friendly for you:
https://github.com/Vanshikapandey30/Hackt
oberFest2021