---
# Metadata used for sync
id: "983e61f0-5452-11ed-b9f8-277f58bcc5e3"
title: "have to do"
source: ""
created_date: "2022-10-25"
modified_date: "2022-10-26"
deleted: true
---
How to slowly make every day
better
1. Make a list of things that make
you happy
2. Make a list of things you
do everyday
3. Compare the lists
4. Adjust accordingly

When your kids are born,
reserve them dn eMdil address.
photos,
Over the years send them
notes, kid-SMG, Storie5, phorocop85
of their achievements etc.
On their 18th birthdav

Become friends with people who aren't
your age. Hang out with people whose
first language isn't the same as yours.
Get to know someone who doesn't come
from your social class. This is how you
see the world. This is how you grow.


If you're good at something, never do it for free. 

Make sure you do what
you love, because
somewhere there will be
someone who loves what
you are doing and they will
surely outwork you.


We learn from books, but also from people
we talk to, and the various positions, ideas,
and opinions we are exposed to. We have
to know how to sort through the relevant
information and discard what is not worth
learning.


One thing that changed my
life: initiating conversations
with people around me.
At airports, at work, in a lift,
wherever/whenever I get a
chance.


Comfort is a drug
which only a few have
the balls to say no to.