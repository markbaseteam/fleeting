---
# Metadata used for sync
id: "249779b0-60d9-11ed-bb62-9599cdb4e8bb"
title: "how to "
source: ""
created_date: "2022-11-10"
modified_date: "2022-11-10"
deleted: true
---
1. Pick a brush with lots of texture. My favorite to use is
my Rocco Procreate Brush because it gives a bit of a
vintage paper texture to the illustration
2. Create a new layer over your illustration layer. Now, I
usually go with a black color for most of my illustrations
since they are pretty light and bright but if I was doing a
darker illustration, I'd choose a color somewhere near
around a light grey
3. Cover the entire piece with the brush you chose. Do
not overdo it where it just comes out looking like a solid
color. Make sure you can see the texture and have some
transparent bits so you can still see a bit of your illustration
underneath. These type of brushes work best I think!
4 Click the little "N" next to the layer with your texture.
Scroll down until you see the "Overlay" option. Click that
and then set your opacity down until you like how it looks!
Thať's it!! t's so simple. I use this trick on most of my
illustrations to give it that little bit of extra "oomph!"
The first brush I used is the #Rocco Texture Brush,. the
second brush is the +NEW Canvas Texture Brush and
the last brush used is the NEW Denim Texture Brush.
All work great for this little Procreate hack! I have a few
texture brushes in my shop but these definitely are my
favorite.
I hope this little tip works for you guys!+


Which brush should we use
to make eyes and nose
Any brush that works like this is enough to
make all sorts of illustrations.
In Procreate, it is Hard Blend.
In MediBang Paint, it is Watercolour Wet.