---
# Metadata used for sync
id: "e51ec7f0-5450-11ed-924d-195bac68edbe"
title: "ideas to follow"
source: ""
created_date: "2022-10-25"
modified_date: "2022-10-25"
deleted: true
---
 The exercise is something I call a Year in the
Life. During the selected year, I take at least one photo per day. When
rhe vear ends, I chronicle my ycar in a coffee table photo book (thank


website where you are matched with someone having the extreme opposite
of your opinion on a certain topic
you all deliberately sign up to convince people from the other side

Varun Mayya  @VarunMayya 3h
Call it Fight Club

