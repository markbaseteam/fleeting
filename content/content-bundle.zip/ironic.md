---
# Metadata used for sync
id: "13c79f00-51ea-11ed-9a44-c3314a54f396"
title: "ironic"
source: ""
created_date: "2022-10-22"
modified_date: "2022-10-22"
deleted: true
---
It's Ironic
When a man starts earning money, he
plans to build a family and take more
responsibilities.
Whereas when a woman starts earning
money, she plans to become more
independent.
How ironic is that! 


I don't need love I need baap dada ka andha paisa
Replying to @poojaasanwal

My kids will have this but I'll be strict