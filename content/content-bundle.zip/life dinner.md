---
# Metadata used for sync
id: "085e5de0-70bf-11ed-a319-f5c85942bf30"
title: "life dinner"
# Extracts all tags in content into the metadata
tags: []
source: ""
created_date: "2022-11-30"
modified_date: "2022-11-30"
deleted: true
---
@SystemSunday
-Life Dinner: Why-
Life Dinner is a scheduled time to check in with your significant other.
It's like agile planning (with your most important client)
The process builds intimacy, trust, & accountability.

-Life Dinner: How-
Set a recurring calendar invite on the 1st of every month.
The session can take as little as 20 mins
But it's better to have 1-2 hrs allotted (if you need it).

During "Life Dinner," you'll discuss 3 overarching categories:
1. Personal Reflection on Last Month
2. Relationship Reflection on Las
3. Personal Goals for Next Month
Let's dive into each...

1. Personal Reflection on Last Month
Guiding Questions:
• What could I have done better?
• What was I proud of?
•What's causing me anxiety?
• What am I worried about for the future?


2. Relationship Reflection on Last
Month
Guiding Questions:
• What's one little thing we not ed about each other that we love?
•Are there things we learned about from our relationship?
• How might we want to improve moving forward?



3. Personal Goals for Next Month
Guiding Question:
• What do I want to achieve over the next 4 weeks?
(This is helpful for prioritization and accountability.)


Now, some guiding principles:
1. No stonewalling. Don't close up or detach while having tough conversations.
2. Be in the moment. Approach everything from a place of love. Ask thoughtful questions.
3. Prepare ahead of time. Keep a running journal of things you want to discuss.

