---
# Metadata used for sync
id: "0e3ef490-60d9-11ed-9d60-bf435be3aa22"
title: "lin"
source: ""
created_date: "2022-11-10"
modified_date: "2022-11-10"
deleted: true
---
Log on to Linkedin, and find out a few people that have
Similar titles as you are looking for - e.g. you might be
interested in a strategy consultant role. Find out what kind
of profiles do these people have - what kind of subjects
have they studied, what roles have they held in the past. Try
to find out if you can tell a story that is similar in terms of
coursework/job roles.
2Maybe you have some pre-requisites covered, and you
still require some. In that case "close the gap". You can
close the gap through certification programs or taking up
independent projects to demonstrate your proficiency in the
subject.
3 Call on to all of your fungible skills! Fungible skills are
skills that you can use anywhere. Collaboration, team work,
influencing people, thinking about solutions, project
management, creating good visual presentations,
storytelling- all these are fungible skills. You can use them
anywhere!
4Sometimes you will need a stepping stone - i.e. you
might have to take upa job for a few (2-3) years -as a way
to get your story right so that you land your dream job. This
is relevant when you want to shift domains or change
industries.
BONUS TIP: Do not ever talk yourself out of striving for
your dream job. Do not think - "you are too old, or too
young". Desires and actions towards our goals is what keep
us young. 