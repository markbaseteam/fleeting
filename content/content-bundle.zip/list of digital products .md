---
# Metadata used for sync
id: "305be190-6800-11ed-a45a-fdf258645066"
title: "list of digital products "
source: ""
created_date: "2022-11-19"
modified_date: "2022-11-24"
deleted: true
---
DIGITAL ART AND PRINTABLES
• Patterns and textures
Clip art
Vector graphics
Business logo packs
Greeting card designs
Printable wall art
Printable games
Printable colouring pages
Printable wedding invites
Printable party invites
Printable party decorations
Printable party tags
Printable scrapbook papers
• Phone evites


TEMPLATES
Business card templates
Powerpoint templates
Photoshop templates
Blog or web graphics
Social media graphics
Phone backgrounds
• Email scripts / swipe files


SOFTWARE
• Wordpress themes
Website templates
Mobile apps
Video games
Plugins
• Web-based applications or software


PATTERNS
Sewing patterns
Craft templates
SVG Cricut files
Knitting patterns
Crochet patterns



AUDIO & MUSIC
Podcasts
Audiobooks
Foreign language lessons
Karaoke
Sound effects
Musical tracks
Audio clips
• Ringtones and jingles


DOCUMENTS
Resumes
Lead magnets
Checklists
Guides
Action plans
Forms
Spreadsheets
Contracts


EDUCATION
Courses
Workshops
Resource libraries
Online community groups
Membership sites
Workbooks
Worksheets
• Lesson plans


PLANNERS & ORGANIZERS
Printable journal prompts
Printable calendars
Printable planners
Habit trackers
Progress trackers

PHOTOGRAPHY
• Stock photography
Mock-ups
Photoshop actions
