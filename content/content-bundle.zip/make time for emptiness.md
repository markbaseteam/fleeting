---
# Metadata used for sync
id: "97c8f4c0-51ea-11ed-8092-4f859d698a13"
title: "make time for emptiness"
source: ""
created_date: "2022-10-22"
modified_date: "2022-10-22"
deleted: true
---
1. MAKE TIME FOR EMPTINESS
First, observe yourself
Be with yourself as you are, but without haste, without impatience
In our everyday lives, do any of us have time to think
about nothing?
I imagine most people would say, I don't have a moment to
spare for that."
We're pressed for time, pressured by work and everything else
in our lives. Modern life is busier than ever. All day, every day,
we try our bestjust to do what has to get done.


If we immerse ourselves in this kind of routine, unconsciously but
inevitably we lose sight of our true selves, and of true happiness.