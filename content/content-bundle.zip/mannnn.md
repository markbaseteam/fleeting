---
# Metadata used for sync
id: "64603350-550f-11ed-93dc-9704e3fb8120"
title: "mannnn"
source: ""
created_date: "2022-10-26"
modified_date: "2022-10-26"
deleted: true
---

When we admit
what we don't know,
it inereases the chanee
that someone,
who does know,
will offer to help.