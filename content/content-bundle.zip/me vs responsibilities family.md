---
# Metadata used for sync
id: "20d3cf40-54d6-11ed-afd8-e33df88a34e7"
title: "me vs responsibilities family"
source: ""
created_date: "2022-10-26"
modified_date: "2022-10-26"
deleted: true
---
Do you think giving too
much time or efforts to
family can ruin my
future?
Simple!
When it's time to grow, don't try
to live. Otherwise, you will have
to grow when it's time to live.
But make sure to fulfill your
responsibilities for your people without
being a slave of system.
Responsibilities nibhao, lekin untouched
raho. 