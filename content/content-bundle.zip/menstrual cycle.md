---
# Metadata used for sync
id: "6cbcd730-67ff-11ed-a45a-fdf258645066"
title: "menstrual cycle"
source: ""
created_date: "2022-11-19"
modified_date: "2022-11-24"
deleted: true
---

nourishyourcycle Many of us are losing YEARS of our lives to our menstrual health struggles because we were never taught that things could be any different.
To figure out just how many years you are so called
"destined" to struggle, use this formula:
Symptomatic cycle days × # of cycles you have per year >
40 fertile years of our lives = # of days in your fertile years
spent struggling.
Then divide that number by 365
There you have it.
If anyone, and I mean ANYONE,