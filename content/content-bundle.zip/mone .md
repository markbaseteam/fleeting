---
# Metadata used for sync
id: "f4333830-6f8e-11ed-a3ee-e9fa0d462aff"
title: "mone "
# Extracts all tags in content into the metadata
tags: []
source: ""
created_date: "2022-11-29"
modified_date: "2022-11-30"
deleted: true
---
It's much easier to earn extra
$10,000/yr, than trying to cut your annual expenses by $10,000.
Making an extra $10,000/yr is just:
$833/month
$192/week
$27/day
Anyone can do this as barista, Uber, pizza delivery, etc.
But most won't because of their ego.

If you give yourself 30 days to clean your home, it will take you 30 days. But if you give yourself
3 hours, it will take you 3 hours
the same applies to your goals, ambitions and potential.