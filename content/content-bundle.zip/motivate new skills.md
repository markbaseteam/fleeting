- [ ] ![[doodling arrow ]]
- [ ] ![[difference bw reading ]]
- [ ] ![[choice]]
- [ ] ![[write in obsidian]]
- [ ] ![[varun mayya post comments]]
- [ ] ![[varun 76o inst apost]]
- [ ] ![[types of mnemonics]]
- [ ] ![[truth bombs via nakul]]
- [ ] ![[today]]
- [ ] ![[thr scoratix methid]]
- [ ] ![[thealiporepost Dont procrastinate livi]]
- [ ] ![[start up ideas]]
- [ ] ![[speech]]
- [ ] ![[soroow]]
- [ ] ![[self awareness part2]]
- [ ] ![[self awareness part 1]]
- [ ] ![[self Discovery thought]]
- [ ] ![[self Discovery Thought of the day]]
- [ ] ![[sales tips ]]
- [ ] ![[ry [fileName I phrase to displayll]]
- [ ] ![[remembering tech or languave]]
- [ ] ![[relationship trend]]
- [ ] ![[qu]]
- [ ] ![[pen pal]]
- [ ] ![[paraocdm]]
- [ ] ![[option]]
- [ ] ![[occupations deepstash]]
- [ ] ![[netflix sound]]
- [ ] ![[nazar lag gaye]]
- [ ] ![[my feelings]]
- [ ] ![[motivate new skills]]
- [ ] ![[megh_bluebird One good thing does not]]
- [ ] ![[me vs responsibilities family]]
- [ ] ![[mannnn]]
- [ ] ![[make time for emptiness]]
- [ ] ![[ironic]]
- [ ] ![[insta prices ]]
- [ ] ![[ideas to follow]]
- [ ] ![[Fleeting/have to do]]
- [ ] ![[grief]]
- [ ] ![[gossip to make money]]
- [ ] ![[freelan money]]
- [ ] ![[first step of survival]]
- [ ] ![[finance.  hhbb]]
- [ ] ![[emotionally over an dunder available]]
- [ ] ![[dyk]]
- [ ] ![[chetna]]
- [ ] ![[digital. money]]
- [ ] ![[Morning vs Night Person]]
- [ ] ![[dailt encouragment]]
- [ ] ![[How to think creatively]]
- [ ] ![[Heart vs Mind ]]
- [ ] ![[car]]
- [ ] ![[business experience]]
- [ ] ![[books check]]
- [ ] ![[book thought]]
- [ ] ![[alter ego game]]
- [ ] ![[after death]]
- [ ] ![[You have to do this ]]
- [ ] ![[Whenever you feel unproductive, check wh]]
- [ ] ![[Varun mayya stoey]]
- [ ] ![[Varsity zerodha course]]
- [ ] ![[Up work clients]]
- [ ] ![[Tricks to do]]
- [ ] ![[The apprentice Experiment]]
- [ ] ![[The Growth Paradox]]
- [ ] ![[Taking action hard]]
- [ ] ![[Take your time to identify your conflict]]
- [ ] ![[Story of your life idea]]
- [ ] ![[Story ]]
- [ ] ![[Social Media Categories]]
- [ ] ![[Skillshare class]]
- [ ] ![[Sample Mail]]
- [ ] ![[Rule of One Thing]]
- [ ] ![[Relatable check]]
- [ ] ![[Realtable]]
- [ ] ![[Raj Shamani]]
- [ ] ![[Podcast twitter space]]
- [ ] ![[Personal Dream]]
- [ ] ![[Persevrance]]
- [ ] ![[People's page]]
- [ ] ![[Parallel world]]
- [ ] ![[Paisa Paisa]]
- [ ] ![[Overthinking as profit ]]
- [ ] ![[Overthink]]
- [ ] ![[Obsidian tip]]
- [ ] ![[Obsidian sim]]
- [ ] ![[No two people are the same, and no two p]]
- [ ] ![[My daughter]]
- [ ] ![[Moti]]
- [ ] ![[Find happiness quickly by varun agarwla]]
- [ ] ![[Moral Stories]]
- [ ] ![[Manifestation]]
- [ ] ![[Like and love]]
- [ ] ![[Life Hacks]]
- [ ] ![[Leetcode]]
- [ ] ![[Journaling aporoches]]
- [ ] ![[I beleive]]
- [ ] ![[How much percent]]
- [ ] ![[HeadWay]]
- [ ] ![[Digital Drwaing]]
- [ ] ![[Focus time]]
- [ ] ![[Family Treasure]]
- [ ] ![[Feelings by Varun Mayya]]
- [ ] ![[Cool ]]
- [ ] ![[Bus travel Timepass ]]
- [ ] ![[DM in Insta answer]]
- [ ] ![[Art Instagram]]
- [ ] ![[Clarity of thoughts]]
- [ ] ![[Art Questions and all]]
- [ ] ![[Better Orator]]
- [ ] ![[Art or Content]]
- [ ] ![[A duff version]]
- [ ] ![[Are you Scared]]
- [ ] ![[100 Percent]]
- [ ] ![[50 productive things]]
---
# Metadata used for sync
id: "c145d690-4959-11ed-8c69-018bdb7298bb"
title: "motivate new skills"
source: ""
created_date: "2022-10-11"
modified_date: "2022-10-11"
deleted: true
---
How do you motivate yourself to learn new skills?
-by developing a sense of
curiosity
How do you develop curiosity?
- by activating the child inside
you. The child is always curious
and we all have a child inside us.
Don't try to be an adult all the
time. Discovering your child
gives you access to parts of your
brain that your adult side
cannot:)

And notice how you
always criticise the child
inside you.
Imagine you have a child
and you're always
criticising it. It's going to
feel like shit right.
That's what you're doing
to yourself. Nurture the
child within you and then
you'll release your infinite
potential.