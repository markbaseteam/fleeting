---
# Metadata used for sync
id: "ae6093b0-5374-11ed-b187-51f176f7f963"
title: "my feelings"
source: ""
created_date: "2022-10-24"
modified_date: "2022-10-24"
deleted: true
---
People who've been using Obsidian for over
a year: are you still tempted to constantly
tweak your workflow and find yourself
spending more time setting up than actually
Working?
I'm in academia and found out about Obsidian about 6
weeks ago. Migrating all my literature notes from Word
is taking a while but it's worth it considering how I can
integrate Zotero and build a wiki to work with my notes.
I'm amazed at the incredible capabilities of the software,
especially with added plugins. But with every fantastic
discovery comes more tweaking and even thoughI love
doing that, I also fear that Obsidian will be a constantly
evolving wormhole.
I'Il make myself stop setting up at some point, but ľ'm
curious about the experience of those of you who've
been with Obsidian for a long while.

Check reddit 