---
# Metadata used for sync
id: "3c422b80-51ea-11ed-8092-4f859d698a13"
title: "nazar lag gaye"
source: ""
created_date: "2022-10-22"
modified_date: "2022-10-22"
deleted: true
---
So Nazar lag gaya is basically an ancient
form of cognitive dissoance
What is cognitive dissonance?
Remember the fable where a fox that
tries to eat grapes from a vine but
cannot reach them. Rather than admit
defeat, he states they are undesirable
and sour and walks away. That is
basically cognitive dissonance.
It basically means when our
expectations don't match our reality our
brain protects us by either changing our
belief or our action


So Nazar lag gaya is basicallya form of
protection where if the expectation doesn't
match the reality then the brain can protect you
from feeling really bad.
Cognitive Dissonance unfortunately is not a very
good thing if your belief systems are not fully
formed.
For example, let's say you know it's important to
save and invest money but you end up spending
all your money anyway
Now obviously since you didn't end up saving or
investing you going to experience cognitive
dissonance and hence feel guilty about it
And in order to resolve cognitive dissonance, you
have 2 options. To alter your thought or your
action
So you basically tell yourself nah I want to chill
and enjoy my life because I'Il anyway won't live
for long and hence you resolve the conflict
without feeling any guilt


You may have also noticed
how you keep going back to
your toxic relationship and
then justify their actions to
your friend telling your friends
they're not that bad?
Because you think your bflgf
loves you so when they do
crazy shit you experience
cognitive dissonance. And
your brain once again tries to
protect you by choosing to
reaffirm the belief that they
love you.