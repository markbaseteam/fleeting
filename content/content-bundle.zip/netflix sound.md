---
# Metadata used for sync
id: "eb4b0170-536f-11ed-8e30-0d9231901f36"
title: "netflix sound"
source: ""
created_date: "2022-10-24"
modified_date: "2022-10-24"
deleted: true
---
The sound is a combination of
several things
Lon Bender's wedding ring hitting the
side of a bedroom cabinet...
..aslowed anvil sound with muted hits
.and what Netflix calls the blossom -
basically, a guitar sound in reverse...
All of this came together to create
the iconic sound Ta-Dum. 