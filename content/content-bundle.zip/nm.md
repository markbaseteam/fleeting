---
# Metadata used for sync
id: "977c1d80-61b2-11ed-8c5b-533efebee8e3"
title: "nm"
source: ""
created_date: "2022-11-11"
modified_date: "2022-11-11"
deleted: true
---
1. Do, don't say
I've always been someone who believes in
manifesting. In action-oriented living. At the
same time, it's equally easy to be swayed by
the hundred good ideas l'd want to pursue and
then the disappointment when most of those
don't see the light of day. This also applies to
unrealistic goals like quitting bad habits, or just
staying on top of things constantly.
The solution, as a friend taught me, was Do,
don't say. Take that first step, follow through,
then feel good about it. The whole jazz about
The Secret and the universe making things
happen once you put the intention out is
bullshit, in my opinion and experience. Keep it
real. Watch an idea or habit grow. Then, when it
feels like you've actually gone ahead and done
it, celebrate.
It's a similar philosophy to the architect Ludwig
Mies van der Rohe's famous edict Build, don't
talk, which another friend told me about last
week... 