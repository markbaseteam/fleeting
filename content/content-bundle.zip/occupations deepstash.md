---
# Metadata used for sync
id: "0c6194f0-4fb5-11ed-ad9c-b5b0b2d9f8a9"
title: "occupations deepstash"
source: ""
created_date: "2022-10-19"
modified_date: "2022-10-19"
deleted: true
---
16. Anthropologist
Anthropology is the study of cultures.
Unlike economics, which tends to focus
on mathematical models, or psychology,
which tends to do a lot of careful
experiments,
Anthropologists Ilearn about cultures by
man immersing in them.
How could you immerse yourself in
groups to which you don't belong?
Groups of different nationalities or
languages? Politics or professions?
How could you learn how those groups
of people function, have them accept
you as you live alongside them? these
answers lie in anthropology


18. Critic
Many critics go beyond telling you which
books to read and which movies to watch.
They build analysis, interpretation and
discussion that goes well beyond the original
work.
The thinking tools involved are quite
important, even for people who don't analyze
literature for a living.
For starters, there is the ability to pay quite
close attention to creative works.
Experiencing something much more deeply
than just a shallow consumer.
Second, there's the tool of being able to
connect that knowledge to a web of other
issues and ideas.


19. Philosopher
one of the philosophers powerful tools
is being able to see the unexpected
consequences of stretching an idea to its
limits.
This has two benefits.
1. it can reveal flaws in the original idea, by
reductio ad absurdum.
2. this can help you recognize the
fundamental principles behind your
vague intuitions of things.
By exposing your ideas to stronger,
hypothetical critiques, you can see the real
mechanisms by which they work.


22. Novelist
Many people see stories as the linguistic
embodiment of history.
.We take what actually happened and
weave it into some words so others can
see it for themselves.
Unfortunately, people understand stories
much better than realities.
So often you need to package up the
histories you want to tell people ina
way that they can interpret.
While this applies to writing novels or
making movies.
Telling stories is a part of everyone's life.
From "Why do you want to work at this
job' to, "Where do you see yourself in five
years?"
.These are all stories, and we need to
understand their structures.



23. Actor
A popular thinking tool for acting is
called method acting.
This technique involves trying to actually
feel the emotions of the character you're
portraying, rather than just faking it.
This may seem to be a contradiction:
how can you feel something you know is
fake?
Changing your emotional state to get
the results you want is a great tool used
by actors.
Feeling insecure, but know you need
confidence?
Why can't you summon that up in
yourself as if you're playing a part?
But don't fake it-feel it.

