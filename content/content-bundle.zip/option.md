---
# Metadata used for sync
id: "be479050-5502-11ed-8043-d3f6c74b2aab"
title: "option"
source: ""
created_date: "2022-10-26"
modified_date: "2022-10-26"
deleted: true
---
INTROVERT INCLUSION
Sometimes we want to
be left alone.
Sometimes we want to
be included.
Most of the time we want to
be included with the option
to be left alone. 