---
# Metadata used for sync
id: "bca275a0-51fe-11ed-b119-394abf2b46c9"
title: "pen pal"
source: ""
created_date: "2022-10-22"
modified_date: "2022-10-22"
deleted: true
---
What is Pen Pal?
Back in the 90s we would
randomly write handwritten
letters to strangers across
the world. Their address
would be given in a pen pal
book. And then they would
write youa letter back and
you would eventually become
friends 