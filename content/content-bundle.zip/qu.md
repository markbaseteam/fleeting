---
# Metadata used for sync
id: "73490490-5452-11ed-93dc-1fcb70746156"
title: "qu"
source: ""
created_date: "2022-10-25"
modified_date: "2022-10-25"
deleted: true
---
One thing I've learnt the past year is that if you
don't like something, take action! There is always a
solution, even if it isn't the ideal one