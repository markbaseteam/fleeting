---
# Metadata used for sync
id: "849c02e0-60d9-11ed-9c00-91c0cfddaef3"
title: "rela"
source: ""
created_date: "2022-11-10"
modified_date: "2022-11-10"
deleted: true
---
1, Savarika Sharma is super annoyed with my life. I don't
feel that I'm the only Indian daughter belonging to a
conservative middle class family, who is unhappy with
her life. There are many more. l always feel neglected
around my own people. Since childhood I've been
finding the answer, that is why my brother Shiv and
other male members in the family get more attention
than girls in the society. But till now I'm struggling to
find my answer. Because of all this I never loved
spending quality time with my family, I love my own
company. Honestly, I never feel that unbreakable
connection with any of my family members. It doesn't
Pmean that I hate them all, I love them and also care 
I'm 14 now and still struggling to understand my family.
Now I used to be quieter, I sleep late at night and wake
early in the morning, because this is the only time I
managed to nourish talent. Books become my best

Though there are massive disapproval between adults
and Teens. The ultimate aim of them is to ensure their
child's happiness and not to struggle like how they
were. Because seeing someone regret, even after so
many warnings is the most unbearable thing.
One must be confident enough to give confidence to
their parents that they are capable of what they desire.