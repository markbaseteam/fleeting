---
# Metadata used for sync
id: "ec07fe10-51e9-11ed-aded-ab00b1bb9d78"
title: "relationship trend"
source: ""
created_date: "2022-10-22"
modified_date: "2022-10-22"
deleted: true
---
An interesting relationship
trend is now emerging.
People in their early 20s are
happier in shorter and more
meaningful relationships
rather than longer and
unfulfilling ones.
The whole concept of "Happily
ever after" after needs to re
looked at:)


Please stop asking me for
relationship advice guys.
I've only had one relationship
my entire life.
The only advice I can give is
being single is literally the best
thing in the world provided you
like your own company.
And if you find someone who
you think is compatible with
you then you should definitely
be with them:)