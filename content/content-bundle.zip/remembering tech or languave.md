---
# Metadata used for sync
id: "dd81ae80-51fe-11ed-a211-793a2c1a46f5"
title: "remembering tech or languave"
source: ""
created_date: "2022-10-22"
modified_date: "2022-10-22"
deleted: true
---
THE KEYWORD METHOD
In this method, an English word that sounds similar
to the word of a foreign language is identified. This
English word will function as the keyword.
For example, if you want to
remember the Spanish word for
duck which is 'Pato, you may
choose 'pot' as the keyword and
then evoke images of keyword
and the target word and imagine
them as interacting
This method of learning words of a foreign language
is much superior compared to any kind of rote
memorization.


THE METHOD OF LOCI
It requires that you first visualize objects/places that
you know well in a specific sequence, then imagine
the objects you want to remember and associate
them one by one to the physical locations5.

For example, suppose you want to remember breau
ggs, tomatoes, and soap on your way to the market.
You may visualize a loaf of bread and eggs placed in
your kitchen, tomatoes kept on a table and s0ap in
the bathroom.
When you enter the market all you need to do is to
take a mental walk along the route from your
kitchen to the bathroom recalling all the items of
your shopping list in a sequence.


MNEMONICS USING
ORGANIZATION
Organization refers to imposing certain order on the
material you want to remember.
A) CHUNKING:
In chunking
several smaller units
are combined to form
large chunks.
For creating chunks, it is important to discover some
organization principles, which can link smaller units.
Therefore, apart from being a control mechanism to
increase the capacity of short-term memory.
chunking can be used to improve memory as well


B) FIRST LETTER TECHNIQUE
In this technique, the first letter of each word is
arranged to form another word or a sentence.
For example, colours of a rainbow are
remembered as VIBGYOR-that stands for Violet,
Indigo, Blue, Green, Yellow, Orange and Red.