---
# Metadata used for sync
id: "15fe2b60-4955-11ed-8bb0-c56e55bf0ad2"
title: ""
source: ""
created_date: "2022-10-11"
modified_date: "2022-10-11"
---
ry: [fileName I phrase to displayll

Sanctum theme

I keep https://copypastecharacter.com/ in my browser
favorites if I cannot remember the key combo for any :)_

then let's make them executable:
chmod +x push.sh pull.sh
From now on, you can push and pull
executing those scripts with:
./pull. sh
./push.sh



Settings Plugin options Backlinks
Then, in "more options" for the note, click on "Toggle
backlinks in document".


.Website: https://www.zsolt.blog/

