---
# Metadata used for sync
id: "afc0f080-5444-11ed-addd-a74f7b6c0863"
title: "sales tips "
source: ""
created_date: "2022-10-25"
modified_date: "2022-10-25"
deleted: true
---
Potential buyer asks:
"Can I speak to the
manufacturer of the
product?"
Expert response: Ma'am can I
know the issue you want to clarify,
accordingly I can get the correct
person to answer your queries. We
can have our company get you the
clarifications from the brand.




1. Preparation:
If you wanna sell something, you need
to be prepared!
Let's say, you want to sell your course.
You need to be prepared, with the thing
you are selling and You need to show
your authority and show them why you
are the best person to learn from.

You can do this by sharing the things
you have done in your past or the impact
your product has created in other
people's lives so far.
Now you are prepared to show the world
why you are the best, it is not enough to
get that purchase. You have to attack E


2. Emotion:
Emotions are only of two types.
- Dream
- Fear
You have to either help your customer
dream big or scare him because anyone
and everyone gets out of their bed
because of one of these two reasons.


The person already knows you are
credible because you nailed Step 1,
now they are more inclined to buy from
you.



3. Urgency
Raj, "I see your point, but I think I'l buy
it later"
When you get this response, what does
it mean?
Even when you have created the "Need"
there needs to be an element that
propels the customer to make the move
"Now".



You have to give your customer the
feeling of "This is it, I need it now". Once
this urgency kicks in, the sale happens!
And that's how you become great at sales.
Now you can apply this P+E+U Formula
in any phase of your life and walk out as
a winner.