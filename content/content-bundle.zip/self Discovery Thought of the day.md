---
# Metadata used for sync
id: "b2189520-4faf-11ed-9b89-1dc3e8fe4b0c"
title: "self Discovery Thought of the day"
source: ""
created_date: "2022-10-19"
modified_date: "2022-10-19"
deleted: true
---
Self Discovey Thought for today
Have you ever found yourself struggling at
work?
This mostly happens when your personality
doesn't match with your job.
Let's say you are a people person and are
stimulatied with having people around then
sitting in a cubicle all day will suck out your
journey
Let's say you're a quite introverted person
then trying to be an entrepreneur which
involves the complete opposite will stress
you out.
Let's say you want to create an impact then
working for a purely capitalistic company
won't feed your soul



Getting to know more about
yourself and your true
personality (minus all the
conditioning) will help you find
the right job and also will help
you excel at work:)


Also you need to be very empathetic
towards your personality.
For example Gary Vee will scream at
you saying why aren't you fucking
starting up and you're losing time
and what's wrong with you. But if
your personality type doesn't match
that of an entrepreneur then you'll
feel bad yourself and criticise
yourself more and Gary Vee will
criticise you even more.
Whatever your personality type is,
it's your strength. Don't let someone
tell you otherwise


10 years ago I used to give such
motivational talks but I now
realise the problem with with
motivational books and
content.
Most of them assume that
every human being is the same.
Which is such a big disrespect
to something as beautiful and
complex as the human mind.

Take atomic habits as an
example. It assumes everyone
should love habits and will
succeed purely on the adoption
of the technique.

But are millions and millions of
people who hate habits and
that actually brings their
creativity and thoughts down


In conclusion all of this
motivational content that's is
constantly forced upon usis
becoming redundant and has O
no value compared to self
discovery and knowing and
understanding yourself better.
Because every human is
unique. That's what makes us
human.
Ok that's it. I'm retiring from
Ted Talks