---
# Metadata used for sync
id: "9f8e9a50-5377-11ed-afc6-af68c8ea3462"
title: "self Discovery thought"
source: ""
created_date: "2022-10-24"
modified_date: "2022-10-24"
deleted: true
---
Self-Discovery thought for today
- Are you scared of failure?
- Feel stuck and like you can't do anything in life
Often compare yourself to others
- Find it hard to motivate yourself and end up
procrastinating a lot
- Doubt yourself a lot?
- Find it hard to face rejection?
- Find it hard to love yourself?
There could one more reasons but one common
reason is - low self-worth
Having low self-worth is not your fault. It usually
happens when your needs are not met as a child.
If you work on self-worth, most of the problems
listed above go away in time :) 