---
# Metadata used for sync
id: "03a8f8d0-51d6-11ed-ba76-f9f6b5014b4b"
title: "self awareness part 1"
source: ""
created_date: "2022-10-22"
modified_date: "2022-10-22"
deleted: true
---
Self-Awareness Series Part 1
Have you noticed how motivational
videos inspire you for just 5 minutes?
Or you end up procrastinatingg
endlessly on that idea.
Here's how it works: We as humans
have a conscious mind and a
subconscious mind. Most of us are
only aware of our conscious minds
because that's where we process all
our information.
Our subconscious mind is like a little
kid and receives most of its
information when we were little kids


So even though our conscious mind
knows what it wants our subconscious
mind creates something known as
limiting belief that holds us back.
For example, let's say your father was
always busy working hard to make
money or struggling financially when
you were growing up.
Your subconscious took this in at face
value and might have developed beliefs
such as: Money = struggle
Cut to you as an adult and , in your
conscious mind, would like to make
money but you're subconsciously
mistrusting of money and think you'lI
end up struggling.
These subconscious belief then create
a limiting belief that hold you back


So the real trick to stop
procrastinating is
understating your belief system first. 
Because humans are not meant to
procrastinate. It's literally
not in our evolution.
It's basically the limiting
belief that causes you to
procrastinate