---
# Metadata used for sync
id: "d4ebcae0-51d5-11ed-972d-558ddacc30d2"
title: "self awareness part2"
source: ""
created_date: "2022-10-22"
modified_date: "2022-10-22"
deleted: true
---
Self-Awareness Video Series
Part 2
In part 1 we discussed about
limiting belief. For example if
as a child you assumed
having fun is irresponsible
then there's a high chance
you'll hardly go travelling
even though you want to.
Or if you saw your parents
fight a lot then you'll be
averse to relationships or
even if you get into them
you'll sabotage them.

In part 2 of the series
we discuss about
Confirmation Bias.
The problem is if you
have a certain belief
system then
confirmation bias
reinforces that belief
system



What is confirmation Bias
Confirmation bias is basically your mind
looking for evidence that confirms your
existing belief system
Let's say you keep going back to that toxic ex
and every single time you have to justify your
ex's behaviour to your friends. That's because
your mind believes your ex loves you. So when
they exhibit negative or toxic behaviour your
mind tries to justify it.
Instagram's algorithm runs on the concept of
confirmation bias. It shows you content that
aligns with your belief system. If you think
crypto is a scam it will show you similar
content and if you think crypto is real it will
show you content that aligns with your beliefs
How to overcome confirmation bias? Follow
this page and keep watching this series to
know more