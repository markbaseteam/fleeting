---
# Metadata used for sync
id: "2bdfa970-4fb0-11ed-9b89-1dc3e8fe4b0c"
title: "soroow"
source: ""
created_date: "2022-10-19"
modified_date: "2022-10-19"
deleted: true
---
Bhai life me sb kharab
chal rhah
Acha ek baat btatu hu, according to
Shiv Puraan, this Earth is the planet of
misery and sorrow.
Every human will suffer happiness and
sadness here. And due to the stupid
nature of human, they will not enjoy
happiness but perfectly suffer sadness.
Therefore, it is called the planet of
sorrow.
Only that being who remains calm and
still in both bad and good situations. No
sorrow can make him feel bad and no
happiness can make him feel excited.
Only that way, you can live without any
dukh dard, peeda. 