---
# Metadata used for sync
id: "84f54da0-520b-11ed-a13a-798e4be9f328"
title: "speech"
source: ""
created_date: "2022-10-22"
modified_date: "2022-10-22"
deleted: true
---
Let your speech pass through these 3 Gates and
you will never hurt people around you.
1) Gate of Truth
2) Gate of Necessity
3) Gate of Kindnessate of Truth