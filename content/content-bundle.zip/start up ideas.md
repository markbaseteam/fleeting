---
# Metadata used for sync
id: "e277a220-51f2-11ed-bd25-894ae7e5281e"
title: "start up ideas"
source: ""
created_date: "2022-10-22"
modified_date: "2022-10-22"
deleted: true
---
Problem:
Young people across India want to give back to
society. They find meaning by helping. It also
fullfils the soul and helps in building a strong
purpose. A great country is only built when
citizens of the country start giving back in every
meaningful way
Right now the only meaningful way through
technology is to give back by donating. I've run
100s of these campaigns and while it definitely
helps I don't feel the joy of actually going on
ground and doing some work.
Solution
An online platform that enables young people to
give their time to people in need. You can teach at
an orphanage, you can spend time at an old age
home, you can help widows run small business.
More than money you give them time (which I feel
is more fulfilling)
The platform will list activities and you can select
the activity you want to be a part of and signup.