---
# Metadata used for sync
id: "59e5e570-520b-11ed-bb90-f53f316a20d0"
title: ""
source: ""
created_date: "2022-10-22"
modified_date: "2022-10-22"
deleted: true
---
thealiporepost "Don't procrastinate living your life
ecause of the thoughts in your head. You have given
these thoughts lite. You can end them. It is hard, yes.
But it must be done. You owe it to yourself to protect
your mind. Growing a tree is also hard. Do you think
that the earth waits for conditions to be perfect before
growing anything? Nature just keeps going whether it is
having a bad-sprout-day or not. Control your thoughts
and be a little hard on yourself for your own good. Your
ideas about your own success or failure are Supplied to you by yourselI. BelIevein something other than the
binary of winning or losing. Believe in smearing your life
with a spectrum of experiences rather than having to
constantly weigh nem against a score board or against
a bonk of philosophy Constantly measuring your life
takes the fun away from living."