---
# Metadata used for sync
id: "9ce545e0-536f-11ed-b30d-ed434835a64f"
title: "thr scoratix methid"
source: ""
created_date: "2022-10-24"
modified_date: "2022-10-24"
deleted: true
---
The Socratic Method
When you're in the middle of an argument,
frame your disagreements in the form of
questions.
This gives the other person a chance to
respond without feeling cornered and
threatened.