---
# Metadata used for sync
id: "d0839730-5374-11ed-b187-51f176f7f963"
title: "today"
source: ""
created_date: "2022-10-24"
modified_date: "2022-10-24"
deleted: true
---
For now is the only
time that we have. It is
Our only negotiable
Currency.
Yesterday is a
canceled check.
Tomorrow is a
promissory note.
It is only today that we
may spend in the
noble effort of using
all the gifts that God
gave us.
-Keith DeGreen 