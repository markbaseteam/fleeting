---
# Metadata used for sync
id: "76c26e30-5cf5-11ed-ac0c-f95d84c8ff83"
title: "tr"
source: ""
created_date: "2022-11-05"
modified_date: "2022-11-05"
deleted: true
---
Get on the top of Burj khalita (123rd floor) for Just 2200 Rs which also includes
your breakfast. The normal príce being 5000 Rs per person to get on the top (this
doesn't even include anything to eat or drink).
IETo do this you have to reserve a table from the website
'http://atmosphereburjkhalifa.com/
-Go and select the option 'Breakfast in the Clouds
You only need a reservation to go up there and the minimum billing amount should
be of 10o AED per person which is 2200 Rs.
Follow and Share @travelwithprajwall for more hacks like this !