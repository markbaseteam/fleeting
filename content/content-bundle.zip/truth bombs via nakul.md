---
# Metadata used for sync
id: "103c3bf0-5377-11ed-8445-3d33aa3cbdbf"
title: "truth bombs via nakul"
source: ""
created_date: "2022-10-24"
modified_date: "2022-10-24"
deleted: true
---
As we grow older we realise our greatest
struggles might be with our own heart. We are
not taught, however, how to articulate these
struggles so we do things that we unable to fully
explain. Language is an essential life-skill taught
with very little interest these days. There is a
reason why we relate to the meme-culture. It is
because memes say in a snapshot what we are
unable to say in sentences, no matter how long
and winding. Focus on what your heart is telling
you, 