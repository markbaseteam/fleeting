---
# Metadata used for sync
id: "b58ca360-5377-11ed-b56e-e1cbd98e484a"
title: "types of mnemonics"
source: ""
created_date: "2022-10-24"
modified_date: "2022-10-24"
deleted: true
---
The basic types of mnemon ics include:
Keyword Mnemonics
Chunking
Musical Mnemonics
Letter and Word Mnemonics
Rhymes
Making Connections
Method of Loci Mnemonic
+Peg Method Mnemonics 