---
# Metadata used for sync
id: "3ab953e0-60d8-11ed-9d60-bf435be3aa22"
title: "ux case study"
source: ""
created_date: "2022-11-10"
modified_date: "2022-11-10"
deleted: true
---
Case studies are the core of your portfolio.
Here's how I would structure my case study:
1. Exec summary (problem, insights, solution)
2. Research and insights (main learnings)
3. Prototyping (sketching & wireframing)
4. Testing (usability tests & analysis)
5. Results (mockups &outcomes)
l'd aim for 2000-words max fora typical project.
And for as many pictures, visuals, and mockups as
possible.
Here are 13 portfolios I love:
bpowell. c
cherupil. com
robonilla. com
lynnsohn. com
chriswelch. co
alexlakas. com
stijnthijssen. nl
yuyangluo. com
taamannae. dev
yinghsuanho. com
karoliskosas. com
jaeyouchung. com
camillemormal. com
Good luck with creating a portfolio that doesn't suck.
It's a challenge. I think mine sucks as well.
Please share your portfolio in the comments if it helped
you get a job.
It's helpful to many new designers to get inspiration.