---
# Metadata used for sync
id: "71b9d5f0-6230-11ed-95d9-916bc4c79d45"
title: "ux tip"
source: ""
created_date: "2022-11-12"
modified_date: "2022-11-17"
deleted: true
---
I've been trying to remove sharp
edges around all Ul elementsI
make and l'm realising how all
daily use items in the real world
has ZERO sharp edges.
In nature, only harmful stuff has
sharp edges. Everything else
has a border radii of around 2px
The more the radii, the more
harmless a Ul will look. Gollu
Mollu stuff doesn't look harmful
but sharp edgy stuff makes us
feel intimidated. That's why fit
people intimidate us while gollu
mollu babies make us go aw