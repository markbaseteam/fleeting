---
# Metadata used for sync
id: "516f4040-51fb-11ed-a3e6-47b90b99fa4e"
title: "varun 76o inst apost"
source: ""
created_date: "2022-10-22"
modified_date: "2022-10-22"
deleted: true
---
I started travelling solo 6 months
ago, I have been to 4 solo trips
now, the feeling of independence
there is nothing like it, I was tired
of waiting around for friends to go
to the places I wanted to see ,The
best part of solo trip is you will get
to see the places you want to
see ,the food you want to taste, the
people you want to meet, and
mostly of you want to see a sunset
for 10 more minutes you can sit
and watch nobody is going to ask
you to walk back..the best
decision of my life was deciding to
travel solo
Hey can I share this?
Yesss Varun pleaseee, 1 2as very
shy kid growing up and I never
though I would take up solo trips, I
was scared I was anxious but to
every time my anxiety said I can'ti
have my mind gutt will pulled my
anxiety up
I want more girls to explore the
options of solo trip


What @mahathi_kamath
described in the previous post is
definitely a brilliant way to
conquer your anxiety and fears.
It's by going through the
discomfort. I remember when
my brother passed l knew I haad
lost my friend forever. I decided
to spend an entire year with
myself. No meeting my old
friends or anyone that was really
close to me. Just sitting with my
discomfort every single day in
and day out.
It's painful and it's very hard but
when you come out of it it's
empowering:)