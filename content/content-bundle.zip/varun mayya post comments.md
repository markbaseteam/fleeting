---
# Metadata used for sync
id: "5a2a94c0-51f9-11ed-9b6b-55dd66eece34"
title: "varun mayya post comments"
source: ""
created_date: "2022-10-22"
modified_date: "2022-10-22"
deleted: true
---
thevarunmayya @prayagimperius 1 08
this is the problem with laymen
reading science. There's a concept
called "effect size" that determines
the magnitude of the effect of an
intervention. All studies about cold
showers prove that they work but the
effect size is so tiny you can forget
about it being useful in practice.
prayagimperius108 @thevarunmayya
agreed! But if you dive into the depth
of it (i have done that), you will come
to know that this has immense
benefits. I speak this because i
have had personal improvements in
my life. Obviously for many people
nothing works coz they are just
lookina for external motivations. 