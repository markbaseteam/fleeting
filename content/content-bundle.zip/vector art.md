---
# Metadata used for sync
id: "e502ecd0-60d8-11ed-9d60-bf435be3aa22"
title: ""
source: ""
created_date: "2022-11-10"
modified_date: "2022-11-10"
deleted: true
---
1. vector art
price: 400/-
2. detailed art
price:500-
3. swap art
price:800 /-

Your favorite brush?
It totally depends on which
softwarei am using..
I mostly work in 1ois Paint and
I have so many tavorite brushes
1. Colored Pencil
2. Pen fade
3. Flat waterco lor mix
4. Alcohol marker
5. Gouache opaque

Drawing Gui For Instagram Square:
dit Drawing Gu 1080pxX 1080px
For Instagram Portrait:
1080px X 1350px
How to maintain the quality of
digital art on Instagram as it
ruins the quality