---
# Metadata used for sync
id: "3538f100-60d8-11ed-9d60-bf435be3aa22"
title: ""
source: ""
created_date: "2022-11-10"
modified_date: "2022-11-10"
deleted: true
---
what's a big red flag for you?????
i was talking about red flags w a
friend recently. one of the red
flags for me is when other person
doesn't or finds it difficult to
apologise.
i feel it's y difficult to have a
long term friendship/relationship w
them. kyunki fuck ups toh dekho dono
hi karenge over time, it's a fact of
1ife, but if you' re able to realise
vour mistakes and dil se apologise
its easier to resolve and forget
things , otherwise things just stick
w you and stuff piles up. SoOoOoo0.
(another majo red flag is they
don' t 1ike early 2000s ke bollywood