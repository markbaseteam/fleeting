---
# Metadata used for sync
id: "db39b570-495a-11ed-8a84-b53e699cfa3e"
title: "write in obsidian"
source: ""
created_date: "2022-10-11"
modified_date: "2022-10-11"
deleted: true
---
1. Tag types #on/.. for different subjects, or #log/... for
date type notes, #status/.. don't really use this yet, but
may use it in the future for projects. e.g. #on/psychology
or #on/programming. Or #type/podcast, #type/book.
2. Insert it quickly with a template. Name the template
with a special character so that it appears first in your list
of templates e.g. Underscores
3. Use auto note mover plugin and set up a rule that
moves #on/psychology notes to your psychology
folder. This will depend on if you like using folders to
organise, or if you have a flat system like logseq uses, or
somewhere in between. I am somewhere in between...
Perhaps I'l work towards an organisation similar to
Eleanor Konik's notees.
4. Create organisation in your vault using MOCs that you
create yourself. But by copy pasting the contents page of
a text book or course learning outcomes you can create
the pages as you learn about each new chapter and
that way you build structure yourself and your vault, but
without having to reinvent the entire subject.
keep it all in one vault. There is absolutely no reason
to separate psychology and computer programming
notes... Actively look for common links to tie your
knowledge together... that will be useful. Even
incorporate personal notes if possible.
don't use dataview to create MOCs... It will take so long
to understand how to use it, which will be an important
opportuníty cost for your work output, and you wont get
the benefit of using your own brain to create meaningfu
MOCs. Stay away from dataview. It's great, attractive,
shiny, but not needed.

---
alias
publish: true
tags: on/psychology
---